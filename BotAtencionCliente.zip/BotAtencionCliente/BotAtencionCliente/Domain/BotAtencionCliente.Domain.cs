﻿using System.Text;

namespace BotAtencionCliente.Domain
{
    public class Cliente
    {
        public long ChatId { get; set; } // Agregar esta propiedad
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public int Edad { get; set; }
        public string Direccion { get; set; }
        public DateTime FechaRegistro { get; set; }

        public Cliente(long chatId, string nombre, string telefono, int edad, string direccion)
        {
            ChatId = chatId; // Asigna el chatId
            Nombre = nombre;
            Telefono = telefono;
            Edad = edad;
            Direccion = direccion;
            FechaRegistro = DateTime.Now; // Asigna la fecha actual
        }
    }


    public class Producto
    {
        public int Id { get; set; }
        public string Referencia { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public int CantidadEnStock { get; set; }

        public Producto(int idProducto, string referencia, string nombre, decimal precio, int cantidadEnStock)
        {
            Id = idProducto;
            Referencia = referencia;
            Nombre = nombre;
            Precio = precio;
            CantidadEnStock = cantidadEnStock;
        }
    }

    public class Cotizacion
    {
        public List<Producto> Productos { get; set; }
        public List<decimal> Precios { get; set; }
        public List<int> Cantidades { get; set; }
        public decimal Total { get; set; }
        public string NombreUsuario { get; set; }
        public string Telefono { get; set; }
        public int IdFactura { get; set; }

        public Cotizacion()
        {
            Productos = new List<Producto>();
            Precios = new List<decimal>();
            Cantidades = new List<int>();
        }

        public void CalcularTotal()
        {
            Total = 0;
            for (int i = 0; i < Productos.Count; i++)
            {
                Total += Precios[i] * Cantidades[i];
            }
        }

        public string GenerarMensajeCotizacion()
        {
            StringBuilder mensaje = new StringBuilder();
            mensaje.AppendLine("Cotización:");
            for (int i = 0; i < Productos.Count; i++)
            {
                mensaje.AppendLine($"Producto: {Productos[i].Nombre}, Cantidad: {Cantidades[i]}, Precio: {Precios[i]}, Subtotal: {Precios[i] * Cantidades[i]}");
            }
            mensaje.AppendLine($"Total: {Total}");
            return mensaje.ToString();
        }
    }

}
