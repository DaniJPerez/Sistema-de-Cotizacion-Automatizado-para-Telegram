﻿using BotAtencionCliente.Domain;
using BotAtencionCliente.Data;
using System.Collections.Generic;

namespace BotAtencionCliente.Business.Services
{
    public class GestorDePedidos
    {
        private readonly RepositorioClientes _repositorioClientes;

        public GestorDePedidos(RepositorioClientes repositorioClientes)
        {
            _repositorioClientes = repositorioClientes;
        }

        public void RegistrarPedido(int clienteId, List<Producto> productos)
        {
            var cliente = _repositorioClientes.ObtenerClientePorId(clienteId);
            if (cliente != null)
            {
                //var nuevoPedido = new Pedido(_repositorioPedidos.ObtenerNuevoIdPedido(), cliente, productos);
                //_repositorioPedidos.GuardarPedido(nuevoPedido);
            }
        }
    }
}
