﻿using BotAtencionCliente.Business.Services;
using BotAtencionCliente.Data;
using BotAtencionCliente.Api;
using Telegram.Bot;

class Program
{
    static async Task Main(string[] args)
    {
        var botClient = new TelegramBotClient("7739474181:AAEpyd8TXBiei4dF5z-xdT_W0diH8n2HvFg");

        var repositorioClientes = new RepositorioClientes();
        var repositorioProductos = new RepositorioProductos();
        var repositorioCotizaciones = new RepositorioCotizaciones();

        var botController = new BotController(repositorioClientes, repositorioProductos, repositorioCotizaciones);

        await botController.StartAsync(botClient);
    }
}
