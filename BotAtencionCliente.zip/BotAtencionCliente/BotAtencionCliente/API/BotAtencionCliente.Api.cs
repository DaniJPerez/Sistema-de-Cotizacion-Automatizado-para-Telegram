﻿using Telegram.Bot;
using Telegram.Bot.Types;
using BotAtencionCliente.Business.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BotAtencionCliente.Data;
using BotAtencionCliente.Domain;

namespace BotAtencionCliente.Api
{
    public class BotController
    {
        private readonly RepositorioClientes _repositorioClientes;
        private readonly RepositorioProductos _repositorioProductos;
        private readonly RepositorioCotizaciones _repositorioCotizaciones;

        private readonly Dictionary<long, Cliente> clientesPendientes = new Dictionary<long, Cliente>();
        private readonly Dictionary<long, int> pasoRegistro = new Dictionary<long, int>();
        private readonly Dictionary<int, Func<long, string, ITelegramBotClient, Task>> pasosRegistro;
        private readonly Dictionary<long, List<Producto>> productosCotizacion = new Dictionary<long, List<Producto>>();

        // Añadido el parámetro repositorioCotizaciones en el constructor
        public BotController(RepositorioClientes repositorioClientes, RepositorioProductos repositorioProductos, RepositorioCotizaciones repositorioCotizaciones)
        {
            _repositorioClientes = repositorioClientes;
            _repositorioProductos = repositorioProductos;
            _repositorioCotizaciones = repositorioCotizaciones;  // Asegurar que se inicializa correctamente

            pasosRegistro = new Dictionary<int, Func<long, string, ITelegramBotClient, Task>>()
            {
                { 1, ObtenerTelefono },
                { 2, ObtenerEdad },
                { 3, ObtenerDireccion },
                { 4, ConfirmarDatos }
            };
        }

        public async Task StartAsync(TelegramBotClient botClient)
        {
            botClient.StartReceiving(HandleUpdateAsync, HandleErrorAsync);
            Console.WriteLine("Bot started...");
            Console.ReadLine();
        }

        private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            if (update.Message != null && update.Message.Text != null)
            {
                var chatId = update.Message.Chat.Id;
                var messageText = update.Message.Text;

                if (messageText.StartsWith("/start"))
                {
                    await botClient.SendTextMessageAsync(chatId, "¡Bienvenido al bot de atención al cliente!");
                    await botClient.SendTextMessageAsync(chatId, "Comandos:\n/registrar\n/catalogo\n/cotizar\n/perfil");
                }
                else if (messageText.StartsWith("/registrar"))
                {
                    var cliente = new Cliente(chatId, update.Message.Chat.FirstName, "", 0, "");
                    clientesPendientes[chatId] = cliente;
                    pasoRegistro[chatId] = 1;
                    await botClient.SendTextMessageAsync(chatId, "Por favor, ingrese su número de teléfono:");
                }
                else if (clientesPendientes.ContainsKey(chatId) && pasoRegistro.ContainsKey(chatId))
                {
                    int pasoActual = pasoRegistro[chatId];
                    await pasosRegistro[pasoActual].Invoke(chatId, messageText, botClient);
                }
                else if (messageText.StartsWith("/catalogo"))
                {
                    var catalogo = _repositorioProductos.ObtenerCatalogoProductos();
                    var mensajeCatalogo = catalogo.Any()
                        ? "Catálogo de productos:\n" + string.Join("\n", catalogo.Select(p => $"ID: {p.Id} - {p.Nombre} - ${p.Precio} - Stock: {p.CantidadEnStock}"))
                        : "No hay productos disponibles en el catálogo.";
                    await botClient.SendTextMessageAsync(chatId, mensajeCatalogo);
                }
                else if (messageText.StartsWith("/perfil"))
                {
                    var cliente = _repositorioClientes.ObtenerClientePorId(chatId);
                    var mensajePerfil = cliente != null
                        ? $"Perfil:\nNombre: {cliente.Nombre}\nTeléfono: {cliente.Telefono}\nEdad: {cliente.Edad}\nDirección: {cliente.Direccion}\nFecha de Registro: {cliente.FechaRegistro:yyyy-MM-dd}"
                        : "No se encontraron datos de perfil. Regístrese usando /registrar.";
                    await botClient.SendTextMessageAsync(chatId, mensajePerfil);
                }
                else if (messageText.StartsWith("/cotizar"))
                {
                    productosCotizacion[chatId] = new List<Producto>();
                    await botClient.SendTextMessageAsync(chatId, "Ingrese el ID del producto que desea cotizar:");
                }
                else if (productosCotizacion.ContainsKey(chatId))
                {
                    if (productosCotizacion[chatId].Any() && productosCotizacion[chatId].Last().CantidadEnStock == 0)
                    {
                        if (int.TryParse(messageText, out int cantidad) && cantidad > 0)
                        {
                            productosCotizacion[chatId].Last().CantidadEnStock = cantidad;
                            await botClient.SendTextMessageAsync(chatId, $"Producto agregado: {productosCotizacion[chatId].Last().Nombre} - Cantidad: {cantidad}. ¿Desea agregar otro producto? (si/no)");
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(chatId, "Cantidad no válida. Intente de nuevo.");
                        }
                    }
                    else if (messageText.ToLower() == "si")
                    {
                        await botClient.SendTextMessageAsync(chatId, "Ingrese el ID del próximo producto que desea cotizar:");
                    }
                    else if (messageText.ToLower() == "no")
                    {
                        var totalCotizacion = productosCotizacion[chatId].Sum(p => p.Precio * p.CantidadEnStock);
                        var mensajeCotizacion = "Cotización:\n" + string.Join("\n", productosCotizacion[chatId].Select(p => $"{p.Nombre} - ${p.Precio} x {p.CantidadEnStock} = ${p.Precio * p.CantidadEnStock}")) + $"\nTotal: ${totalCotizacion}\n";
                        await botClient.SendTextMessageAsync(chatId, mensajeCotizacion);

                        var cotizacionId = _repositorioCotizaciones.GuardarCotizacion(chatId, totalCotizacion);
                        _repositorioCotizaciones.GuardarDetalleCotizacion(cotizacionId, productosCotizacion[chatId]);

                        await botClient.SendTextMessageAsync(chatId, "Cotización guardada exitosamente en la base de datos.");
                        productosCotizacion.Remove(chatId);
                    }
                    else if (int.TryParse(messageText, out int idProducto))
                    {
                        var productoSeleccionado = _repositorioProductos.ObtenerCatalogoProductos().FirstOrDefault(p => p.Id == idProducto);
                        if (productoSeleccionado != null)
                        {
                            productosCotizacion[chatId].Add(new Producto(idProducto, "", productoSeleccionado.Nombre, productoSeleccionado.Precio, 0));
                            await botClient.SendTextMessageAsync(chatId, $"Producto {productoSeleccionado.Nombre} seleccionado. Ingrese la cantidad deseada:");
                        }
                        else
                        {
                            await botClient.SendTextMessageAsync(chatId, "ID de producto no válido. Intente de nuevo.");
                        }
                    }
                }
                else
                {
                    await botClient.SendTextMessageAsync(chatId, "Comando no reconocido.");
                }
            }
        }

        private Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            Console.WriteLine($"Error: {exception.Message}");
            return Task.CompletedTask;
        }

        private async Task ObtenerTelefono(long chatId, string messageText, ITelegramBotClient botClient)
        {
            clientesPendientes[chatId].Telefono = messageText;
            pasoRegistro[chatId] = 2;
            await botClient.SendTextMessageAsync(chatId, "Por favor ingrese su edad:");
        }

        private async Task ObtenerEdad(long chatId, string messageText, ITelegramBotClient botClient)
        {
            if (int.TryParse(messageText, out int edad))
            {
                clientesPendientes[chatId].Edad = edad;
                pasoRegistro[chatId] = 3;
                await botClient.SendTextMessageAsync(chatId, "Por favor ingrese su dirección:");
            }
            else
            {
                await botClient.SendTextMessageAsync(chatId, "Edad no válida. Por favor ingrese su edad:");
            }
        }

        private async Task ObtenerDireccion(long chatId, string messageText, ITelegramBotClient botClient)
        {
            clientesPendientes[chatId].Direccion = messageText;
            pasoRegistro[chatId] = 4;

            var cliente = clientesPendientes[chatId];
            var mensajeConfirmacion = $"Confirme sus datos:\nNombre: {cliente.Nombre}\nTeléfono: {cliente.Telefono}\nEdad: {cliente.Edad}\nDirección: {cliente.Direccion}\n\n¿Son correctos? (si/no)";
            await botClient.SendTextMessageAsync(chatId, mensajeConfirmacion);
        }

        private async Task ConfirmarDatos(long chatId, string messageText, ITelegramBotClient botClient)
        {
            if (messageText.ToLower() == "si")
            {
                _repositorioClientes.RegistrarCliente(clientesPendientes[chatId]);
                await botClient.SendTextMessageAsync(chatId, "Usuario registrado exitosamente.");
            }
            else
            {
                await botClient.SendTextMessageAsync(chatId, "Registro cancelado.");
            }

            clientesPendientes.Remove(chatId);
            pasoRegistro.Remove(chatId);
        }
    }
}
