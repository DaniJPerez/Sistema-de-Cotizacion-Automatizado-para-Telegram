﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using BotAtencionCliente.Domain;

namespace BotAtencionCliente.Data
{
    public class DatabaseConnection
    {
        private readonly string connectionString;

        public DatabaseConnection()
        {
            // Define tu cadena de conexión directamente en el código aquí.
            connectionString = "Server=LAPTOP-PND5DSHD\\SQLEXPRESS;Database=BotAtencionClienteDB;Integrated Security=True;";
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }

    public class RepositorioClientes
    {
        private readonly DatabaseConnection _dbConnection;

        public RepositorioClientes()
        {
            _dbConnection = new DatabaseConnection();
        }

        public void RegistrarCliente(Cliente cliente)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                connection.Open();
                var query = "INSERT INTO Clientes (ChatId, Nombre, Telefono, Edad, Direccion, FechaRegistro) VALUES (@ChatId, @Nombre, @Telefono, @Edad, @Direccion, @FechaRegistro)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatId", cliente.ChatId);
                    command.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                    command.Parameters.AddWithValue("@Telefono", cliente.Telefono);
                    command.Parameters.AddWithValue("@Edad", cliente.Edad);
                    command.Parameters.AddWithValue("@Direccion", cliente.Direccion);
                    command.Parameters.AddWithValue("@FechaRegistro", cliente.FechaRegistro);

                    command.ExecuteNonQuery();
                }
            }
        }

        public Cliente ObtenerClientePorId(long chatId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                connection.Open();
                var query = "SELECT ChatId, Nombre, Telefono, Edad, Direccion FROM Clientes WHERE ChatId = @ChatId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ChatId", chatId);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Cliente(
                                chatId: reader.GetInt64(0),
                                nombre: reader.GetString(1),
                                telefono: reader.GetString(2),
                                edad: reader.GetInt32(3),
                                direccion: reader.GetString(4)
                            );
                        }
                    }
                }
            }
            return null;
        }
    }

    public class RepositorioProductos
    {
        private readonly DatabaseConnection _dbConnection;

        public RepositorioProductos()
        {
            _dbConnection = new DatabaseConnection();
        }

        public List<Producto> ObtenerCatalogoProductos()
        {
            var productos = new List<Producto>();
            using (var connection = _dbConnection.GetConnection())
            {
                connection.Open();
                var query = "SELECT Id, Referencia, Nombre, Precio, CantidadEnStock FROM Productos";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productos.Add(new Producto(
                                idProducto: reader.GetInt32(0),
                                referencia: reader.GetString(1),
                                nombre: reader.GetString(2),
                                precio: reader.GetDecimal(3),
                                cantidadEnStock: reader.GetInt32(4)
                            ));
                        }
                    }
                }
            }
            return productos;
        }
    }

    public class RepositorioCotizaciones
    {
        private readonly DatabaseConnection _dbConnection;

        public RepositorioCotizaciones()
        {
            _dbConnection = new DatabaseConnection();
        }

        public int GuardarCotizacion(long clienteId, decimal total)
        {
            using var connection = _dbConnection.GetConnection();
            connection.Open();
            var query = "INSERT INTO Cotizaciones (ClienteId, Total) OUTPUT INSERTED.CotizacionId VALUES (@ClienteId, @Total)";
            using var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@ClienteId", clienteId);
            command.Parameters.AddWithValue("@Total", total);

            try
            {
                return (int)command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al guardar la cotización: " + ex.Message);
                throw;
            }
        }

        public void GuardarDetalleCotizacion(int cotizacionId, List<Producto> productos)
        {
            if (productos == null || productos.Count == 0)
            {
                throw new ArgumentException("La lista de productos está vacía o es nula.");
            }

            using var connection = _dbConnection.GetConnection();
            connection.Open();

            using var transaction = connection.BeginTransaction();
            try
            {
                foreach (var producto in productos)
                {
                    var query = "INSERT INTO DetalleCotizacion (CotizacionId, ProductoId, Cantidad, PrecioUnitario) VALUES (@CotizacionId, @ProductoId, @Cantidad, @PrecioUnitario)";
                    using var command = new SqlCommand(query, connection, transaction);
                    command.Parameters.AddWithValue("@CotizacionId", cotizacionId);
                    command.Parameters.AddWithValue("@ProductoId", producto.Id);
                    command.Parameters.AddWithValue("@Cantidad", producto.CantidadEnStock);
                    command.Parameters.AddWithValue("@PrecioUnitario", producto.Precio);

                    command.ExecuteNonQuery();
                }
                transaction.Commit();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Console.WriteLine("Error al guardar el detalle de la cotización: " + ex.Message);
                throw;
            }
        }
    }
}
