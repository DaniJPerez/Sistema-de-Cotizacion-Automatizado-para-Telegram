﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;

namespace DAL
{
    public class ProductoRepository
    {
        string cadena = "Server=.\\SQLEXPRESS;Database=dbExam2;Trusted_Connection=True;";

        SqlConnection _connection;
        public ProductoRepository()
        {
            _connection = new SqlConnection(cadena);
        }
        //1 conectarme

        public bool AbrirConexion()
        {
            try
            {
                _connection.Open();
                if (_connection.State == ConnectionState.Open)
                {
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }

        }



        public List<Producto> SeleccionarRegistros()
        {
            string ssql = "SELECT * FROM TipoAyuda";
            List<Producto> listaAyudas = new List<TipoAyuda>();

            using (SqlCommand cmd = new SqlCommand(ssql, _connection))
            {
                _connection.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        listaAyudas.Add(Mapper(reader));
                    }
                }
            }

            return listaAyudas;
        }
        public List<Producto> SeleccionarRegistros2()
        {
            string ssql = "SELECT * FROM TipoAyuda";
            List<Producto> listaAyudas = new List<Producto>();

            SqlDataAdapter adatador = new SqlDataAdapter(ssql, _connection);
            DataSet ds = new DataSet();
            adatador.Fill(ds);
            var tabla = ds.Tables[0];
            foreach (DataRow dr in tabla.Rows)
            {
                listaAyudas.Add(Mapper2(dr));
            }
            return listaAyudas;
        }
        public Producto Mapper2(DataRow dr)
        {
            return new Producto
            {
               /* Id = dr.Field<int>("Id"), // Asegúrate de que "Id" es el nombre correcto de la columna
                Codigo = dr.Field<string>("Codigo"), // Asegúrate de que "Codigo" es el nombre correcto de la columna
                Descripcion = dr.Field<string>("Descripcion"), // Asegúrate de que "Descripcion" es el nombre correcto de la columna
                Cantidad = dr.Field<int>("Caantidad") // Asegúrate de que "Cantidad" es el nombre correcto de la columna
               */
            };
        }

        private Producto Mapper(SqlDataReader reader)
        {
            return new Producto
            {/*
                Id = reader.GetInt32(reader.GetOrdinal("id")),
                Codigo = reader.GetString(reader.GetOrdinal("Codigo")),
                Descripcion = reader.GetString(reader.GetOrdinal("Descripcion")),
                Cantidad = reader.GetInt32(reader.GetOrdinal("Caantidad"))
                */
            };
        }
    }
}
