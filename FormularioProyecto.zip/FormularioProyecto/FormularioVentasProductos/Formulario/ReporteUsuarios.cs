﻿using Entidad;
using Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class ReporteUsuarios : Form
    {
        private BindingSource bindingSource = new BindingSource();

        UsuarioServices usuarioServices;

        DataTable dataTable;
        public ReporteUsuarios()
        {
            InitializeComponent();
            usuarioServices = new UsuarioServices();

        }

        private void ReporteUsuarios_Load(object sender, EventArgs e)
        {
            CargarTodosLosUsuarios();
        }

        private void LlenarDataGrid(List<Usuario> usuarios)
        {
            try
            {
                // Configuración del DataGridView
                GrillaUsuarios.AutoGenerateColumns = true;
                this.GrillaUsuarios.ClearSelection();

                // Asignar datos al BindingSource
                bindingSource.DataSource = null;
                bindingSource.DataSource = usuarios;

                // Vincular el BindingSource al DataGridView
                this.GrillaUsuarios.DataSource = bindingSource;

                // Configuración de columnas
                GrillaUsuarios.Refresh();
                GrillaUsuarios.Columns[0].Width = 175;
                GrillaUsuarios.Columns[1].Width = 200;
                GrillaUsuarios.Columns[2].Width = 175;

                // Asociar evento de filtrado solo si no está ya asociado
        
                
                txtBusquedadUsuario.TextChanged += new EventHandler(txtBusquedadUsuario_TextChanged);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo realizar la conexión: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtBusquedadUsuario_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBusquedadUsuario.Text;

            // Si el TextBox está vacío, elimina el filtro y muestra todos los datos.
            if (string.IsNullOrWhiteSpace(filtro))
            {
                bindingSource.RemoveFilter();
            }
            else
            {
                // Aplica el filtro para mostrar solo los productos que coincidan con el texto.
                bindingSource.Filter = $"NombreProducto LIKE '*{filtro}*'";
            }
        }

       
        private void btnMenores_Click(object sender, EventArgs e)
        {
            List<Usuario> listaMenosActivos = usuarioServices.SelecionarRegistroMenosActivos();
            LlenarDataGrid(listaMenosActivos);
        }

        // Método que se ejecuta al hacer clic en el botón "Mayor"
        private void btnMayor_Click(object sender, EventArgs e)
        {
            List<Usuario> listaUsuarios = usuarioServices.SeleccionarRegistro();
            LlenarDataGrid(listaUsuarios);
        }

        // Método para llenar el DataGridView con todos los usuarios al cargar el formulario o en situaciones generales
        private void CargarTodosLosUsuarios()
        {
            List<Usuario> listaUsuarios = usuarioServices.SeleccionarRegistro();
            LlenarDataGrid(listaUsuarios); // Usar el método principal
        }
    }
}
