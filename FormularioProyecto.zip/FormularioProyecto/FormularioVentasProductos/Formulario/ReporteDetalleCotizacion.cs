﻿using Entidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logic;
namespace Formulario
{
    public partial class ReporteDetalleCotizacion : Form
    {
        private BindingSource bindingSource = new BindingSource();

        public DetalleCotizacionServices detalleCotizacionServices = new DetalleCotizacionServices();

        public ReporteDetalleCotizacion(int idCotizacion)
        {

            InitializeComponent();
            LlenarDataGrid(idCotizacion);
            
        }

        private void GrillaPedidos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void LlenarDataGrid(int idCotizacion)
        {
            GrillaDetalleCotizacion.AutoGenerateColumns = true;

            this.GrillaDetalleCotizacion.ClearSelection();
            // Carga los datos desde la base de datos o servicio.
            try
            {

                List<DetalleCotizacion> detalle = detalleCotizacionServices.SeleccionarRegistro(idCotizacion);

                bindingSource.DataSource = null;

                // Asocia la lista de productos al BindingSource.
                bindingSource.DataSource = detalle;

                // Vincula el DataGridView al BindingSource.
                this.GrillaDetalleCotizacion.DataSource = bindingSource;
                GrillaDetalleCotizacion.Refresh();
                GrillaDetalleCotizacion.Columns[0].Width = 105;
                GrillaDetalleCotizacion.Columns[1].Width = 130;
                GrillaDetalleCotizacion.Columns[2].Width = 100;
                GrillaDetalleCotizacion.Columns[3].Width = 139;
                GrillaDetalleCotizacion.Columns[4].Width = 120;
                // Asocia el evento TextChanged del TextBox al método de filtrado.
                txtBusquedadDetalle.TextChanged += new EventHandler(txtBusquedad_TextChanged);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo realizar la conexion");
            }

        }

        private void txtBusquedad_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBusquedadDetalle.Text;

            // Si el TextBox está vacío, elimina el filtro y muestra todos los datos.
            if (string.IsNullOrWhiteSpace(filtro))
            {
                bindingSource.RemoveFilter();
            }
            else
            {
                // Aplica el filtro para mostrar solo los productos que coincidan con el texto.
                bindingSource.Filter = $"NombreProducto LIKE '*{filtro}*'";
            }
        }

        private void ReporteDetalleCotizacion_Load(object sender, EventArgs e)
        {
            
        }
    }
}
