﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidad;
using Logic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Formulario
{
    public partial class ReporteProductosCotizados : Form
    {
        private BindingSource bindingSource = new BindingSource();

        ProductosCotizadosServices services;

        DataTable dataTable;
        public ReporteProductosCotizados()
        {
            InitializeComponent();
            services = new ProductosCotizadosServices();
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBusquedadProductosCotizados.Text;

            // Si el TextBox está vacío, elimina el filtro y muestra todos los datos.
            if (string.IsNullOrWhiteSpace(filtro))
            {
                bindingSource.RemoveFilter();
            }
            else
            {
                // Aplica el filtro para mostrar solo los productos que coincidan con el texto.
                bindingSource.Filter = $"NombreProducto LIKE '*{filtro}*'";
            }
        }

        private void ReporteProductosVendidos_Load(object sender, EventArgs e)
        {
            LlenarDataGrid();
        }

        public void LlenarDataGrid()
        {
            GrillaProductosCotizados.AutoGenerateColumns = true;

            this.GrillaProductosCotizados.ClearSelection();
            // Carga los datos desde la base de datos o servicio.
            try
            {

                List<ProductoCotizado> productosVenta = services.SeleccionarRegistro();

                bindingSource.DataSource = null;

                // Asocia la lista de productos al BindingSource.
                bindingSource.DataSource = productosVenta;

                // Vincula el DataGridView al BindingSource.
                this.GrillaProductosCotizados.DataSource = bindingSource;

                GrillaProductosCotizados.Refresh();
                GrillaProductosCotizados.Columns[0].Width = 100;
                GrillaProductosCotizados.Columns[1].Width = 100;
                GrillaProductosCotizados.Columns[2].Width = 100;
                GrillaProductosCotizados.Columns[3].Width = 100;
                GrillaProductosCotizados.Columns[4].Width = 100;

                // Asocia el evento TextChanged del TextBox al método de filtrado.
                txtBusquedadProductosCotizados.TextChanged += new EventHandler(textBox1_TextChanged);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo realizar la conexion");
            }

        }

        
        private void btnProdMenos_Click_1(object sender, EventArgs e)
        {
            List<ProductoCotizado> listaProducto = services.SeleccionarRegistroMenos();
            this.GrillaProductosCotizados.ClearSelection();

            bindingSource.DataSource = null;

            this.GrillaProductosCotizados.DataSource = listaProducto;
        }

        private void btnProdMas_Click(object sender, EventArgs e)
        {
            List<ProductoCotizado> listaProducto = services.SeleccionarRegistro();
            this.GrillaProductosCotizados.ClearSelection();

            bindingSource.DataSource = null;

            this.GrillaProductosCotizados.DataSource = listaProducto;
        }



        /* private void GrillaCotizaciones_CellClick(object sender, DataGridViewCellEventArgs e)
         {
             // Verifica que la celda seleccionada no sea un encabezado
             if (e.RowIndex >= 0)
             {
                 // Obtiene la ID de la cotización de la fila seleccionada
                 int idCotizacion = Convert.ToInt32(GrillaCotizaciones.Rows[e.RowIndex].Cells["IdCotizacion"].Value);

                 // Llama al formulario de detalle de cotizaciones y pasa el ID como parámetro
                 new ReporteDetalleCotizacion(idCotizacion);
             }
         }*/
    }
}
