﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //toca poner un metodo para validar usuarios existentes la base
            if(txtUser.Text.ToUpper()=="USER" && txtPassword.Text.ToUpper() == "123456")
            {
                new Inicio().ShowDialog();
                
            }
            if(txtUser.Text.ToUpper()== "ADMIN" && txtPassword.Text.ToUpper()=="123456")
                new InicioAdmin().ShowDialog();
            else
            {
                MessageBox.Show("Usuario o Contraceña Incorrectos");
                
            }
        }
    }
}
