﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();

            // Configuración inicial de los paneles
            PnInicio.Dock = DockStyle.None; // Panel 1 se ajustará manualmente
            PnInicioOpciones.Dock = DockStyle.None; // Panel 2 se ajustará manualmente

            this.Resize += PnInicioOpciones_Resize;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void buttonReportePedidos_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteCotizaciones(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicio;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonReporteVentas_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteCotizaciones(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicio;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonProductoVendidos_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteProductosCotizados(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicio;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Inicio_Load(object sender, EventArgs e)
        {

        }

        public void MostrarFormularioEnPanel(Form formulario, Panel panel)
        {
            // Configura el formulario secundario para que no tenga borde
            formulario.FormBorderStyle = FormBorderStyle.None;
            formulario.TopLevel = false;
            formulario.Dock = DockStyle.None; // Para mantener un control más preciso de la ubicación

            // Agrega el formulario al panel
            panel.Controls.Clear(); // Limpia el panel si hay otros controles
            panel.Controls.Add(formulario);

            // Calcula la posición centrada del formulario en el panel
            formulario.Left = (panel.Width - formulario.Width) / 2;
            formulario.Top = (panel.Height - formulario.Height) / 2;

            // Muestra el formulario
            formulario.Show();
        }

        private void buttonReporteUsuarios_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteUsuarios(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicio;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void PnInicioOpciones_Resize(object sender, EventArgs e)
        {

            PnInicioOpciones.Width = 480;
            PnInicioOpciones.Height = this.ClientSize.Height; // Ocupa todo el alto de la ventana
            PnInicioOpciones.Location = new Point(0, 0);

            // Calcula el nuevo tamaño para panel2 (expande solo en vertical)

            PnInicio.Width = this.ClientSize.Width - PnInicioOpciones.Width; // Ocupa el ancho restante
            PnInicio.Height = this.ClientSize.Height; // Ocupa todo el alto de la ventana
            // Ajusta su posición al lado de panel1
            PnInicio.Location = new Point(PnInicioOpciones.Width, 0);
        }
    }
}
