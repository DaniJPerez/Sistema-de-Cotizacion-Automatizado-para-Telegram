﻿namespace Formulario
{
    partial class InicioAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSalir = new System.Windows.Forms.Button();
            this.buttonReporteUsuarios = new System.Windows.Forms.Button();
            this.buttonProductoCotizado = new System.Windows.Forms.Button();
            this.buttonReporteVentas = new System.Windows.Forms.Button();
            this.btnGestionProducto = new System.Windows.Forms.Button();
            this.PnInicioAdminOpciones = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PnInicioAdmin = new System.Windows.Forms.Panel();
            this.PnInicioAdminOpciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSalir
            // 
            this.buttonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonSalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSalir.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonSalir.Location = new System.Drawing.Point(78, 619);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(307, 58);
            this.buttonSalir.TabIndex = 17;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = false;
            this.buttonSalir.Click += new System.EventHandler(this.buttonSalir_Click);
            // 
            // buttonReporteUsuarios
            // 
            this.buttonReporteUsuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonReporteUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReporteUsuarios.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReporteUsuarios.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonReporteUsuarios.Location = new System.Drawing.Point(78, 521);
            this.buttonReporteUsuarios.Name = "buttonReporteUsuarios";
            this.buttonReporteUsuarios.Size = new System.Drawing.Size(307, 58);
            this.buttonReporteUsuarios.TabIndex = 16;
            this.buttonReporteUsuarios.Text = "Reporte de Usuarios";
            this.buttonReporteUsuarios.UseVisualStyleBackColor = false;
            this.buttonReporteUsuarios.Click += new System.EventHandler(this.buttonReporteUsuarios_Click);
            // 
            // buttonProductoCotizado
            // 
            this.buttonProductoCotizado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonProductoCotizado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonProductoCotizado.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProductoCotizado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonProductoCotizado.Location = new System.Drawing.Point(78, 426);
            this.buttonProductoCotizado.Name = "buttonProductoCotizado";
            this.buttonProductoCotizado.Size = new System.Drawing.Size(307, 58);
            this.buttonProductoCotizado.TabIndex = 15;
            this.buttonProductoCotizado.Text = "Reporte de Productos mas Cotizados";
            this.buttonProductoCotizado.UseVisualStyleBackColor = false;
            this.buttonProductoCotizado.Click += new System.EventHandler(this.buttonProductoVendidos_Click);
            // 
            // buttonReporteVentas
            // 
            this.buttonReporteVentas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonReporteVentas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReporteVentas.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReporteVentas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonReporteVentas.Location = new System.Drawing.Point(78, 335);
            this.buttonReporteVentas.Name = "buttonReporteVentas";
            this.buttonReporteVentas.Size = new System.Drawing.Size(307, 58);
            this.buttonReporteVentas.TabIndex = 13;
            this.buttonReporteVentas.Text = "Reporte Cotizaciones";
            this.buttonReporteVentas.UseVisualStyleBackColor = false;
            this.buttonReporteVentas.Click += new System.EventHandler(this.buttonReporteVentas_Click);
            // 
            // btnGestionProducto
            // 
            this.btnGestionProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGestionProducto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGestionProducto.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestionProducto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.btnGestionProducto.Location = new System.Drawing.Point(78, 247);
            this.btnGestionProducto.Name = "btnGestionProducto";
            this.btnGestionProducto.Size = new System.Drawing.Size(307, 58);
            this.btnGestionProducto.TabIndex = 19;
            this.btnGestionProducto.Text = "Gestion Productos";
            this.btnGestionProducto.UseVisualStyleBackColor = false;
            this.btnGestionProducto.Click += new System.EventHandler(this.btnGestionProducto_Click);
            this.btnGestionProducto.Resize += new System.EventHandler(this.btnGestionProducto_Resize);
            // 
            // PnInicioAdminOpciones
            // 
            this.PnInicioAdminOpciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.PnInicioAdminOpciones.Controls.Add(this.pictureBox1);
            this.PnInicioAdminOpciones.Controls.Add(this.buttonReporteUsuarios);
            this.PnInicioAdminOpciones.Controls.Add(this.btnGestionProducto);
            this.PnInicioAdminOpciones.Controls.Add(this.buttonReporteVentas);
            this.PnInicioAdminOpciones.Controls.Add(this.buttonSalir);
            this.PnInicioAdminOpciones.Controls.Add(this.buttonProductoCotizado);
            this.PnInicioAdminOpciones.Location = new System.Drawing.Point(1, 1);
            this.PnInicioAdminOpciones.Name = "PnInicioAdminOpciones";
            this.PnInicioAdminOpciones.Size = new System.Drawing.Size(480, 762);
            this.PnInicioAdminOpciones.TabIndex = 20;
            this.PnInicioAdminOpciones.Resize += new System.EventHandler(this.PnInicioAdminOpciones_Resize);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Formulario.Properties.Resources._20240922_155638_removebg;
            this.pictureBox1.Location = new System.Drawing.Point(78, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 197);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // PnInicioAdmin
            // 
            this.PnInicioAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.PnInicioAdmin.Location = new System.Drawing.Point(480, 1);
            this.PnInicioAdmin.Name = "PnInicioAdmin";
            this.PnInicioAdmin.Size = new System.Drawing.Size(1241, 762);
            this.PnInicioAdmin.TabIndex = 21;
            // 
            // InicioAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1719, 762);
            this.Controls.Add(this.PnInicioAdmin);
            this.Controls.Add(this.PnInicioAdminOpciones);
            this.Name = "InicioAdmin";
            this.Text = "InicioAdmin";
            this.Load += new System.EventHandler(this.InicioAdmin_Load);
            this.PnInicioAdminOpciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonSalir;
        private System.Windows.Forms.Button buttonReporteUsuarios;
        private System.Windows.Forms.Button buttonProductoCotizado;
        private System.Windows.Forms.Button buttonReporteVentas;
        private System.Windows.Forms.Button btnGestionProducto;
        private System.Windows.Forms.Panel PnInicioAdminOpciones;
        private System.Windows.Forms.Panel PnInicioAdmin;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}