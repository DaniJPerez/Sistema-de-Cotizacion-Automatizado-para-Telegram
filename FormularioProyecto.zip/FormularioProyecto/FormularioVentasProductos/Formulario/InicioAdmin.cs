﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class InicioAdmin : Form
    {
        public InicioAdmin()
        {
            InitializeComponent();

            // Configuración inicial de los paneles
            PnInicioAdmin.Dock = DockStyle.None; // Panel 1 se ajustará manualmente
            PnInicioAdminOpciones.Dock = DockStyle.None; // Panel 2 se ajustará manualment

            /*
             // Establece posiciones iniciales (si es necesario)
            PnInicioAdmin.Location = new Point(0, 0);
            PnInicioAdminOpciones.Location = new Point(PnInicioAdmin.Width, 0);

             */
            this.Resize += PnInicioAdminOpciones_Resize; // Vincula el evento Resize
        }

        private void buttonSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonReporteUsuarios_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteUsuarios(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicioAdmin;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonProductoVendidos_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteProductosCotizados(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicioAdmin;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonReportePedidos_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteCotizaciones(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicioAdmin;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void buttonReporteVentas_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new ReporteCotizaciones(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicioAdmin;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void InicioAdmin_Load(object sender, EventArgs e)
        {

        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        public void MostrarFormularioEnPanel(Form formulario, Panel panel)
        {
            // Configura el formulario secundario para que no tenga borde
            formulario.FormBorderStyle = FormBorderStyle.None;
            formulario.TopLevel = false;
            formulario.Dock = DockStyle.None; // Para mantener un control más preciso de la ubicación

            // Agrega el formulario al panel
            panel.Controls.Clear(); // Limpia el panel si hay otros controles
            panel.Controls.Add(formulario);

            // Calcula la posición centrada del formulario en el panel
            formulario.Left = (panel.Width - formulario.Width) / 2;
            formulario.Top = (panel.Height - formulario.Height) / 2;

            // Muestra el formulario
            formulario.Show();
        }

        private void btnGestionProducto_Click(object sender, EventArgs e)
        {
            Form formularioSecundario = new GestionProductos(); // Instancia del formulario que deseas mostrar
            Panel panelPrincipal = PnInicioAdmin;
            MostrarFormularioEnPanel(formularioSecundario, panelPrincipal);
        }

        private void btnGestionProducto_Resize(object sender, EventArgs e)
        {
            
        }

        private void PnInicioAdminOpciones_Resize(object sender, EventArgs e)
        {
            PnInicioAdminOpciones.Width = 480;
            PnInicioAdminOpciones.Height = this.ClientSize.Height; // Ocupa todo el alto de la ventana
            PnInicioAdminOpciones.Location = new Point(0,0);

            // Calcula el nuevo tamaño para panel2 (expande solo en vertical)
             
            PnInicioAdmin.Width = this.ClientSize.Width - PnInicioAdminOpciones.Width; // Ocupa el ancho restante
            PnInicioAdmin.Height = this.ClientSize.Height; // Ocupa todo el alto de la ventana
            // Ajusta su posición al lado de panel1
            PnInicioAdmin.Location = new Point(PnInicioAdminOpciones.Width, 0);
        }

        
    }
}
