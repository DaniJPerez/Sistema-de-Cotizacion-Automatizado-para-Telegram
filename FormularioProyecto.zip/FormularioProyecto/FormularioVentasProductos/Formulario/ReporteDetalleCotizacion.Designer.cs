﻿namespace Formulario
{
    partial class ReporteDetalleCotizacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrillaDetalleCotizacion = new System.Windows.Forms.DataGridView();
            this.txtBusquedadDetalle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.GrillaDetalleCotizacion)).BeginInit();
            this.SuspendLayout();
            // 
            // GrillaDetalleCotizacion
            // 
            this.GrillaDetalleCotizacion.AllowUserToAddRows = false;
            this.GrillaDetalleCotizacion.AllowUserToDeleteRows = false;
            this.GrillaDetalleCotizacion.BackgroundColor = System.Drawing.SystemColors.Control;
            this.GrillaDetalleCotizacion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GrillaDetalleCotizacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrillaDetalleCotizacion.Location = new System.Drawing.Point(111, 103);
            this.GrillaDetalleCotizacion.Name = "GrillaDetalleCotizacion";
            this.GrillaDetalleCotizacion.ReadOnly = true;
            this.GrillaDetalleCotizacion.Size = new System.Drawing.Size(635, 344);
            this.GrillaDetalleCotizacion.TabIndex = 8;
            this.GrillaDetalleCotizacion.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrillaPedidos_CellContentClick);
            // 
            // txtBusquedadDetalle
            // 
            this.txtBusquedadDetalle.Location = new System.Drawing.Point(275, 66);
            this.txtBusquedadDetalle.Name = "txtBusquedadDetalle";
            this.txtBusquedadDetalle.Size = new System.Drawing.Size(458, 20);
            this.txtBusquedadDetalle.TabIndex = 9;
            this.txtBusquedadDetalle.TextChanged += new System.EventHandler(this.txtBusquedad_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.label1.Location = new System.Drawing.Point(140, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Buscar Producto Cotizado";
            // 
            // ReporteDetalleCotizacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.ClientSize = new System.Drawing.Size(842, 495);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBusquedadDetalle);
            this.Controls.Add(this.GrillaDetalleCotizacion);
            this.Name = "ReporteDetalleCotizacion";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ReporteDetalleCotizacion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrillaDetalleCotizacion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView GrillaDetalleCotizacion;
        private System.Windows.Forms.TextBox txtBusquedadDetalle;
        private System.Windows.Forms.Label label1;
    }
}