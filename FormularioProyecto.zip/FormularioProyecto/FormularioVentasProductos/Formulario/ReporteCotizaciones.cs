﻿using Entidad;
using Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class ReporteCotizaciones : Form
    {
        private BindingSource bindingSource = new BindingSource();

        CotizacionServices cotizacionServices;
        DataTable dataTable;
        public ReporteCotizaciones()
        {
            InitializeComponent();
            cotizacionServices = new CotizacionServices();
        }

        

        private void GrillaPedidos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Verifica que la celda tenga un valor antes de convertirla.
                var cellValue =  GrillaCotizaciones.Rows[e.RowIndex].Cells["idCotizacion"].Value;
                if (cellValue != null && int.TryParse(cellValue.ToString(), out int idCotizacion))
                {
                    // Llama al formulario de detalle de cotizaciones y pasa el ID como parámetro.
                    new ReporteDetalleCotizacion(idCotizacion).ShowDialog();
                }
                else
                {
                    MessageBox.Show("El valor de la celda seleccionada no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        public void LlenarDataGrid()
        {

            this.GrillaCotizaciones.ClearSelection();
            // Carga los datos desde la base de datos o servicio.
            try
            {
                //GrillaCotizaciones.AutoGenerateColumns = true;


                List<Cotizacion> productosVenta = cotizacionServices.SelecionarRegistro();

                GrillaCotizaciones.AutoGenerateColumns = true;
                // Asocia la lista de productos al BindingSource.
                bindingSource.DataSource = productosVenta;


                // Vincula el DataGridView al BindingSource.
                this.GrillaCotizaciones.DataSource = bindingSource;

                // Asocia el evento TextChanged del TextBox al método de filtrado.
                txtBusquedadCotizacion.TextChanged += new EventHandler(textBox1_TextChanged);
                GrillaCotizaciones.Refresh();
                GrillaCotizaciones.Columns[0].Width = 165;
                GrillaCotizaciones.Columns[1].Width = 165;
                GrillaCotizaciones.Columns[2].Width = 150;
                GrillaCotizaciones.Columns[3].Width = 150;

            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo realizar la conexion"+ex.Message);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBusquedadCotizacion.Text;

            // Si el TextBox está vacío, elimina el filtro y muestra todos los datos.
            if (string.IsNullOrWhiteSpace(filtro))
            {
                bindingSource.RemoveFilter();
            }
            else
            {
                // Aplica el filtro para mostrar solo los productos que coincidan con el texto.
                bindingSource.Filter = $"NombreProducto LIKE '*{filtro}*'";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ReporteCotizaciones_Load(object sender, EventArgs e)
        {
            LlenarDataGrid();
        }
    }
}
