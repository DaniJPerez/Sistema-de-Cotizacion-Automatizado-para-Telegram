﻿using Entidad;
using Logic;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulario
{
    public partial class GestionProductos : Form
    {
        private BindingSource bindingSource = new BindingSource();

        ProductoServices services;
        Producto producto = new Producto();
        public GestionProductos()
        {
            InitializeComponent();
            services = new ProductoServices();
        }

        
        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

       

        

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

      

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

       

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void GrillaProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            producto.Referencia = txtReferenciaAgregar.Text;
            producto.NombreProducto = txtNombreProductoAgregar.Text;
            if (Int32.TryParse(txtIdProductoAgregar.Text, out int idProducto))
            {
                producto.IdProducto = idProducto;
            }
            else
            {
                MessageBox.Show("El Id no tiene formato correcto");
            }
            //SI no se puede convertir, mejor usar variables y agregarles el valor convertido de los texbox
            if (Decimal.TryParse(txtPrecioAgregar.Text, out decimal precio))
            {
                producto.Precio = precio;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("El precio no tiene el formato correcto.");
            }

            // Intenta convertir la cantidad disponible
            if (Int32.TryParse(txtStockAgregar.Text, out int cantidadDisponible))
            {
                producto.cantidadDisponible = cantidadDisponible;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("La cantidad disponible no tiene el formato correcto.");
            }
            bool bandera=false;
            try
            {
                bandera = services.AgregarRegistro(producto);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un problema " + ex.Message);
            }

            
            if (!bandera)
                MessageBox.Show("No se pudo añadir los datos");

            LlenarDataGrid();

        }

        public void LlenarDataGrid()
        {
            this.GrillaProductos.ClearSelection();
            // Carga los datos desde la base de datos o servicio.
            try
            {
                GrillaProductos.AutoGenerateColumns = true;

                List<Producto> productos = services.SeleccionarRegistro();

                this.GrillaProductos.AutoGenerateColumns = true;
                // Asocia la lista de productos al BindingSource.
                this.bindingSource.DataSource = productos;

                // Convierte la lista de productos a un DataTable.
                DataTable dtProductos = ConvertToDataTable(productos);

                // Vincula el DataGridView al BindingSource.
                this.GrillaProductos.DataSource = this.bindingSource;

                // Asocia el evento TextChanged del TextBox al método de filtrado.
                // Asocia el evento TextChanged del TextBox para realizar el filtro.
                txtBusquedadProductos.TextChanged -= txtBusquedadProductos_TextChanged; // Previene duplicar el evento.
                txtBusquedadProductos.TextChanged += txtBusquedadProductos_TextChanged;
                //txtBusquedadProductos.TextChanged += new EventHandler(txtBusquedadProductos_TextChanged);

                GrillaProductos.Columns[0].Width = 140;
                GrillaProductos.Columns[1].Width = 140;
                GrillaProductos.Columns[2].Width = 175;
                GrillaProductos.Columns[3].Width = 100;
                GrillaProductos.Columns[4].Width = 175;

                if (productos == null)
                {
                    MessageBox.Show("No se pudo realizar la conexion");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo realizar la conexion"+ex.Message);
            }

        }

        /*GrillaProductos.Columns[1].Width = 140;
                GrillaProductos.Columns[2].Width = 140;
                GrillaProductos.Columns[3].Width = 175;
                GrillaProductos.Columns[4].Width = 100;
                GrillaProductos.Columns[5].Width = 175;*/
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            producto.Referencia=txtReferenciaAgregar.Text;
            producto.NombreProducto = txtNombreProductoAgregar.Text;
            if (Int32.TryParse(txtIdProductoAgregar.Text, out int idProducto))
            {
                producto.IdProducto = idProducto;
            }
            else
            {
                MessageBox.Show("El Id no tiene formato correcto");
            }
            //SI no se puede convertir, mejor usar variables y agregarles el valor convertido de los texbox
            if (Decimal.TryParse(txtPrecioAgregar.Text, out decimal precio))
            {
                producto.Precio = precio;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("El precio no tiene el formato correcto.");
            }

            // Intenta convertir la cantidad disponible
            if (Int32.TryParse(txtStockAgregar.Text, out int cantidadDisponible))
            {
                producto.cantidadDisponible = cantidadDisponible;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("La cantidad disponible no tiene el formato correcto.");
            }

            bool bandera = false;
            try
            {
                bandera = services.AgregarRegistro(producto);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error " + ex.Message);
            }
           
            if (!bandera)
                MessageBox.Show("No se pudo añadir los datos");

            LlenarDataGrid();

        }

        private void GestionProductos_Load(object sender, EventArgs e)
        {
            LlenarDataGrid();
        }

        private void GrillaProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verifica que la fila seleccionada es válida
            if (e.RowIndex >= 0)
            {
                // Obtiene la fila seleccionada
                DataGridViewRow row = GrillaProductos.Rows[e.RowIndex];

                // Asigna los valores de la fila a los TextBox
                try
                {
                    txtIdProductoEditar.Text = row.Cells["Idproducto"].Value?.ToString() ?? string.Empty;
                    txtReferenciaEditar.Text = row.Cells["Referencia"].Value?.ToString() ?? string.Empty;
                    txtNombreProductoActualizar.Text = row.Cells["nombreProducto"].Value?.ToString() ?? string.Empty;
                    txtStockEditar.Text = row.Cells["cantidadDisponible"].Value?.ToString() ?? string.Empty;
                    txtPrecioEditar.Text = row.Cells["precio"].Value?.ToString() ?? string.Empty;

                    txtIdProductoEliminar.Text = row.Cells["Idproducto"].Value?.ToString() ?? string.Empty;
                    txtNombreProductoEliminar.Text = row.Cells["nombreProducto"].Value?.ToString() ?? string.Empty;
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Lo sentimos, pero aun no hay instancias asignadas a la tabla");
                }

            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            
            producto.Referencia = txtReferenciaEditar.Text;
            producto.NombreProducto = txtNombreProductoActualizar.Text;
            if (Int32.TryParse(txtIdProductoEditar.Text, out int idProducto))
            {
                producto.IdProducto = idProducto;
            }
            else
            {
                MessageBox.Show("El Id no tiene formato correcto");
            }
            if (Decimal.TryParse(txtPrecioEditar.Text, out decimal precio))
            {
                producto.Precio = precio;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("El precio no tiene el formato correcto.");
            }

            // Intenta convertir la cantidad disponible
            if (Int32.TryParse(txtStockEditar.Text, out int cantidadDisponible))
            {
                producto.cantidadDisponible = cantidadDisponible;
            }
            else
            {
                // Manejar el caso cuando el formato no es válido
                MessageBox.Show("La cantidad disponible no tiene el formato correcto.");
            }

            var bandera = services.ModificarProductoServices(producto);
            if (!bandera)
                MessageBox.Show("No se pudo añadir los datos");

            LlenarDataGrid();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            producto.NombreProducto = txtNombreProductoEliminar.Text;
            if (Int32.TryParse(txtIdProductoEliminar.Text, out int idProducto))
            {
                producto.IdProducto = idProducto;
            }
            else
            {
                MessageBox.Show("El Id no tiene formato correcto");
            }
            try
            {
                var bandera = services.eliminarRegistro(producto.IdProducto);
                if (!bandera)
                MessageBox.Show("No se pudo Eliminar Los datos");
            }
            catch(Exception ex)
            {
                MessageBox.Show("No se pudo realizar la modificacion" + ex);
            }
            

            LlenarDataGrid();
        }

        private void btnMostrarProductos_Click(object sender, EventArgs e)
        {
            LlenarDataGrid();
        }

        private void txtBusquedadProductos_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBusquedadProductos.Text.Trim().ToLower();

            try
            {
                if (string.IsNullOrWhiteSpace(filtro))
                {
                    // Elimina cualquier filtro existente si el TextBox está vacío.
                    this.bindingSource.RemoveFilter();
                }
                else
                {
                    // Filtra por el campo "NombreProducto".
                    // Nota: Asegúrate de que el DataTable tenga una columna llamada "NombreProducto".
                    this.bindingSource.Filter = $"NombreProducto LIKE '%{filtro}%'";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al aplicar el filtro: {ex.Message}");
            }
        }

        private DataTable ConvertToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            // Obtiene las propiedades públicas del objeto genérico T.
            var properties = typeof(T).GetProperties();

            // Define las columnas del DataTable según las propiedades del objeto.
            foreach (var prop in properties)
            {
                dataTable.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            // Rellena las filas del DataTable con los valores de la lista.
            foreach (var item in items)
            {
                var values = new object[properties.Length];
                for (int i = 0; i < properties.Length; i++)
                {
                    values[i] = properties[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
    }
}
