﻿using Data;
using Entidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public class ProductoServices
    {
        ProductoRepository productosRepository;
        List<Producto> lisProducto;
        public ProductoServices()
        {
            productosRepository = new ProductoRepository();
            lisProducto = new List<Producto>();
        }

        public List<Producto> SeleccionarRegistro()
        {  
                return productosRepository.SeleccionarRegistros();
        }
        
        public bool AgregarRegistro(Producto producto)
        {
            return productosRepository.AgregarRegistro(producto);
        }
        public bool ModificarProductoServices(Producto producto)
        {
            return productosRepository.ModificarRegistro(producto);
        }

        public bool eliminarRegistro(int idProducto)
        {
            return productosRepository.EliminarRegistro(idProducto);
        }
    }
}
