﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;
using Data;
namespace Logic
{
    public class ProductosCotizadosServices
    {
        ProductosCotizadosRepository productosCotizadosRepository;

        public ProductosCotizadosServices()
        {
            productosCotizadosRepository = new ProductosCotizadosRepository();
        } 

        public List<ProductoCotizado> SeleccionarRegistro()
        {
            return productosCotizadosRepository.productosMasCotizados();
        }

        public List<ProductoCotizado> SeleccionarRegistroMenos()
        {
            return productosCotizadosRepository.productosMenosCotizados();
        }

    }
}
