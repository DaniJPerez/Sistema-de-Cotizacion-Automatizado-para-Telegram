﻿using Data;
using Entidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public class UsuarioServices
    {
        UsuarioRepository usuarioRepository;
        List<Usuario> lisProducto;
        public UsuarioServices()
        {
            usuarioRepository = new UsuarioRepository();
            lisProducto = new List<Usuario>();
        }

        public List<Usuario> SeleccionarRegistro()
        {
            return usuarioRepository.SeleccionarRegistros();
        }

        public List<Usuario> SelecionarRegistroMenosActivos()
        {
            return usuarioRepository.SeleccionarRegistrosMenosActivos();
        }
    }
}
