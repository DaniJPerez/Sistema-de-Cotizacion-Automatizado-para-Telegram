﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class BaseRepository
    {

        private readonly string connectionString;

        public BaseRepository()
        {
            // Define tu cadena de conexión directamente en el código aquí."Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=xepdb1)));User Id=chat_bot;Password=chatbot_bd;";
            connectionString = "Server=MonitorCasa;Database=BotAtencionClienteDB;Trusted_Connection=True;";
;
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public string GetConnectionString()
        {
            return connectionString;
        }

    }
}
