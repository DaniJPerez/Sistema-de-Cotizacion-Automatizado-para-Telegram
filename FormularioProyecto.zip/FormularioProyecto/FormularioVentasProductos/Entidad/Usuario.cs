﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Usuario
    {
        public long IdUsuario { get; set; }
        public string NombreUsuario { get; set; }
        public int cantidadCotizaciones {  get; set; }

    }
}
