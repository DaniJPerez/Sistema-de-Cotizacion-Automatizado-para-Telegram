﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class DetalleCotizacion
    {   
        public int idDetalleCotizacion {  get; set; }
        public int IdCotizacion { get; set; }
        public int IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }

        public decimal PrecioPorProducto { get; set; }

        /*public DetalleCotizacion() { }*/

       /* public DetalleCotizacion(int idDetalleCotizacion, int idCotizacion, int idProducto, string nombreProducto, int cantidad, decimal precio)
        {
            this.idDetalleCotizacion = idDetalleCotizacion;
            IdCotizacion = idCotizacion;
            IdProducto = idProducto;
            NombreProducto = nombreProducto;
            Cantidad = cantidad;
            Precio = precio;
        }*/

        public DetalleCotizacion(int idCotizacion, int idProducto, string nombreProducto, int cantidad, decimal precio, decimal precioPorProducto)
        {
            IdCotizacion = idCotizacion;
            IdProducto = idProducto;
            NombreProducto = nombreProducto;
            Cantidad = cantidad;
            Precio = precio;
            PrecioPorProducto = precioPorProducto;
        }

    }
}
