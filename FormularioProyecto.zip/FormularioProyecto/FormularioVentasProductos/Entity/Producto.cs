﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Producto
    {
        public int IdProducto { get; set; }
        public int IdNegocio { get; set; }
        public string Nombre { get; set; }
        public int cantidad { get; set; }
        public double precio { get; set; }

    }
}
