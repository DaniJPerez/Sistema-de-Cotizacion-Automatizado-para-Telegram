﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;
using Data;
using System.Net.Http.Headers;

namespace Logic
{
    public class DetalleCotizacionServices
    {
        public DetalleCotizacionRepository detalleCotizacion;

        public DetalleCotizacionServices()
        {
            detalleCotizacion= new DetalleCotizacionRepository();
        }

        public List<DetalleCotizacion> SeleccionarRegistro(int idCotizacion)
        {
            return detalleCotizacion.SeleccionarRegistros(idCotizacion);
        }
    }
}
