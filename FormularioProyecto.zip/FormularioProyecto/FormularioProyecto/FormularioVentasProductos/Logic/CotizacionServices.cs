﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;
using Entidad;
namespace Logic
{
    public class CotizacionServices
    {
        CotizacionRepository cotizacionRepository;
        public CotizacionServices()
        {
            cotizacionRepository = new CotizacionRepository();
        }

        public List<Cotizacion> SelecionarRegistro()
        {
            return cotizacionRepository.SeleccionarRegistros();
        }
    }
}
