﻿using Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting.Messaging;
using System.Threading;
using Oracle.ManagedDataAccess.Client;
using System.Data.Common;
using System.Data.Odbc;
using System.CodeDom;
namespace Data
{
    public class ProductoRepository
    {   //recuerda acregar el nombre de la base de datos para poder realizar las busquedas
        //                                 aqui=>   [->       <-]

        private readonly BaseRepository _baseRepository;

        public ProductoRepository()
        {
            _baseRepository = new BaseRepository();
        
        }

        public bool AbrirConexion()
        {
            try
            {

                _baseRepository.GetConnection().Open();

                return true;

            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public bool CerrarConexion()
        {
            try
            {
                _baseRepository.GetConnection().Close();

                return true;

            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public bool AgregarRegistro(Producto producto)
        {
            string query = "INSERT INTO Productos (Id, Referencia, Nombre, Precio, CantidadEnStock) " +
                           "VALUES (@Id, @Referencia, @Nombre, @Precio, @CantidadEnStock)";


            using (var connection = _baseRepository.GetConnection())
            {
                try
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    {
                        // Agregar parámetros con valores
                         command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = producto.IdProducto });
                         command.Parameters.Add(new SqlParameter("@Referencia", SqlDbType.VarChar,50) { Value = producto.Referencia });
                         command.Parameters.Add(new SqlParameter("@Nombre", SqlDbType.VarChar, 50) { Value = producto.NombreProducto });
                         command.Parameters.Add(new SqlParameter("@Precio", SqlDbType.Decimal) { Value = producto.Precio });
                         command.Parameters.Add(new SqlParameter("@CantidadEnStock", SqlDbType.Int) { Value = producto.cantidadDisponible });
                        //Si ocurre un fallo, agregar estas caracteristicas de comandos


                        /*command.Parameters.Add("@Id", producto.IdProducto);
                        command.Parameters.Add("@Nombre_Producto", producto.NombreProducto);
                        command.Parameters.Add("@Precio", producto.Precio);
                        command.Parameters.Add("@Cantidad", producto.cantidadDisponible);*/

                        // Ejecutar la consulta
                        int filasAfectadas = command.ExecuteNonQuery();
                        
                        return filasAfectadas > 0;
                    }
                }
                catch (Exception ex)
                {
                    // Manejo de errores (log o relanzar excepción si es necesario)

                    throw ex;
                }
            }
        }

        public List<Producto> SeleccionarRegistros()
        {
            string ssql = "SELECT * FROM Productos";
            List<Producto> listaAyudas = new List<Producto>();
            try
            { 
                using (var _connection = _baseRepository.GetConnection())
                {
                    _connection.Open();
                    using (SqlCommand cmd = new SqlCommand(ssql, _connection))
                    {
                        
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaAyudas.Add(Mapper(reader));
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listaAyudas;
        }


        public List<Producto> SeleccionarRegistros2()
        {
            string ssql = "SELECT * FROM Productos";
            List<Producto> listaAyudas = new List<Producto>();
            try
            {
                using (var _connection = _baseRepository.GetConnection())
                {
                    SqlDataAdapter adatador = new SqlDataAdapter(ssql, _connection);
                    DataSet ds = new DataSet();
                    adatador.Fill(ds);
                    var tabla = ds.Tables[0];
                    foreach (DataRow dr in tabla.Rows)
                    {
                        listaAyudas.Add(Mapper2(dr));
                    }
                }  
            }
            catch(Exception ex)
            {
                return null;
            }
            return listaAyudas;
        }

        public bool EliminarRegistro(int idProducto)
        {
            string ssql = "DELETE FROM PRODUCTOS WHERE Id = @Id_Producto";
            using (var _connection = _baseRepository.GetConnection())
            {
                _connection.Open();
                using (var command = new SqlCommand(ssql, _connection))
                {
                   
                    try
                    {
                        command.Parameters.Add(new SqlParameter("@Id_Producto", SqlDbType.Int) { Value = idProducto });

                        int filasAfectadas = command.ExecuteNonQuery();

                        // Verifica si alguna fila fue afectada
                        return filasAfectadas > 0;
                    }
                    catch (Exception ex)
                    {
                        // Manejo de errores

                        throw ex;
                    }
                }
            }
            
        }

        public bool ModificarRegistro(Producto producto)
        {
            string query = "UPDATE Productos "+
                            "SET Referencia = @Referencia, " +
                            "Nombre = @Nombre, " +
                            "CantidadEnStock = @CantidadEnStock, " +
                            "Precio = @Precio " +
                            "WHERE Id = @Id;"; 
          
            using (var connection = _baseRepository.GetConnection())
            {
                try
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    {
                        // Agregar parámetros con valores
                       
                        command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = producto.IdProducto });
                        command.Parameters.Add(new SqlParameter("@Referencia", SqlDbType.VarChar, 50) { Value = producto.Referencia });
                        command.Parameters.Add(new SqlParameter("@Nombre", SqlDbType.VarChar, 50) { Value = producto.NombreProducto });
                        command.Parameters.Add(new SqlParameter("@Precio", SqlDbType.Decimal) { Value = producto.Precio });
                        command.Parameters.Add(new SqlParameter("@CantidadEnStock", SqlDbType.Int) { Value = producto.cantidadDisponible });

                        // Ejecutar la consulta
                        int filasAfectadas = command.ExecuteNonQuery();
                        
                        return filasAfectadas > 0;
                    }
                }
                catch (Exception ex)
                {
                    // Manejo de errores (puedes registrar el error si es necesario)

                    throw ex;
                }
            }
        }

        public Producto Mapper2(DataRow dr)
        {
            return new Producto
            {
                IdProducto = dr.Field<int>("Id"), // Asegúrate de que "Id" es el nombre correcto de la columna
                Referencia = dr.Field<string>("Referencia"),
                NombreProducto = dr.Field<string>("Nombre"), // Asegúrate de que "Codigo" es el nombre correcto de la columna
                Precio = dr.Field<decimal>("Precio"),
                cantidadDisponible = dr.Field<int>("CantidadEnStock")// Asegúrate de que "Descripcion" es el nombre correcto de la columna

                
            };
        }

        private Producto Mapper(SqlDataReader reader)
        {
            return new Producto
            {
                IdProducto = reader.GetInt32(reader.GetOrdinal("Id")),
                Referencia = reader.GetString(reader.GetOrdinal("Referencia")),
                NombreProducto = reader.GetString(reader.GetOrdinal("Nombre")),
                Precio = reader.GetDecimal(reader.GetOrdinal("Precio")),
                cantidadDisponible = reader.GetInt32(reader.GetOrdinal("CantidadEnStock"))
                

            };
        }

        private Producto Mapper3(SqlDataReader reader) 
        {
            return new Producto
            {
                IdProducto = !reader.IsDBNull(reader.GetOrdinal("Id"))
                                ? reader.GetInt32(reader.GetOrdinal("Id"))
                                : 0,
                Referencia = !reader.IsDBNull(reader.GetOrdinal("Referencia"))
                                ? reader.GetString(reader.GetOrdinal("Referencia"))
                                : string.Empty,
                NombreProducto = !reader.IsDBNull(reader.GetOrdinal("Nombre"))
                                ? reader.GetString(reader.GetOrdinal("Nombre"))
                                : string.Empty,
                Precio = !reader.IsDBNull(reader.GetOrdinal("Precio"))
                                ? reader.GetDecimal(reader.GetOrdinal("Precio"))
                                : 0,
                cantidadDisponible = !reader.IsDBNull(reader.GetOrdinal("CantidadEnStock"))
                                ? reader.GetInt32(reader.GetOrdinal("CantidadEnStock"))
                                : 0
            };
        }
    }
}
