﻿using Entidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using System.Data.Common;

namespace Data
{
    public class UsuarioRepository
    {
        //recuerda acregar el nombre de la base de datos para porder realizar las busquedas
        //                                 aqui=>   [->       <-]  

        BaseRepository _baseRepository;
        public UsuarioRepository()
        {
            _baseRepository= new BaseRepository();
        }
        //1 conectarme

        public bool AbrirConexion()
        {
            try
            {
                _baseRepository.GetConnection().Open();
                if (_baseRepository.GetConnection().State == ConnectionState.Open)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public bool CerrarConexion()
        {
            try
            {
                _baseRepository.GetConnection().Close();
                if (_baseRepository.GetConnection().State == ConnectionState.Closed)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public List<Usuario> SeleccionarRegistros()
        {
            string ssql = "SELECT c.ChatId AS idUsuario, c.Nombre, COUNT(ct.CotizacionId) AS CantidadCotizaciones " +
                          "FROM Clientes c " +
                          "LEFT JOIN Cotizaciones ct ON c.ChatId = ct.ClienteId " +
                          "GROUP BY c.ChatId, c.Nombre " +
                          "ORDER BY CantidadCotizaciones DESC;";

            /*"Cambia a ASC para mostrar los menos cotizados primero";*/
            List<Usuario> listaUsuarios = new List<Usuario>();

            try
            {
                // Usamos `using` para asegurar que la conexión se cierra automáticamente.
                using (var _connection= _baseRepository.GetConnection())
                {
                    _connection.Open();
                    using (var cmd = new SqlCommand(ssql, _connection))
                    {          
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaUsuarios.Add(Mapper(reader));
                            }
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                // Loguear el error para facilitar la depuración

                throw ex;
            }
            finally
            {
                CerrarConexion();
            }

            return listaUsuarios;
        }

        public List<Usuario> SeleccionarRegistrosMasActivos()
        {
            string ssql = "SELECT c.ChatId AS idUsuario, c.Nombre, COUNT(ct.CotizacionId) AS CantidadCotizaciones " +
                          "FROM Clientes c " +
                          "LEFT JOIN Cotizaciones ct ON c.ChatId = ct.ClienteId " +
                          "GROUP BY c.ChatId, c.Nombre " +
                          "ORDER BY CantidadCotizaciones DESC;";
            List<Usuario> listaAyudas = new List<Usuario>();
            try
            {
                using (SqlConnection _connection = _baseRepository.GetConnection())
                using (var cmd = new SqlCommand(ssql, _connection))
                {
                    _connection.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            listaAyudas.Add(Mapper(reader));
                        }
                    }
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }

            return listaAyudas;
        }

        public List<Usuario> SeleccionarRegistrosMenosActivos()
        {
            string ssql = "SELECT c.ChatId AS idUsuario, c.Nombre, COUNT(ct.CotizacionId) AS CantidadCotizaciones " +
                          "FROM Clientes c " +
                          "LEFT JOIN Cotizaciones ct ON c.ChatId = ct.ClienteId " +
                          "GROUP BY c.ChatId, c.Nombre " +
                          "ORDER BY CantidadCotizaciones ASC;";
            List<Usuario> listaAyudas = new List<Usuario>();
            try
            {
                using (var _connection = _baseRepository.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(ssql, _connection))
                    {
                        _connection.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaAyudas.Add(Mapper(reader));
                            }
                        }
                    }

                }

            }
            catch(Exception ex)
            {
                throw ex;
            }

            return listaAyudas;
        }

        public List<Usuario> SeleccionarRegistros2()
        {
            string ssql = "SELECT c.ChatId AS idUsuario, c.Nombre, COUNT(ct.CotizacionId) AS CantidadCotizaciones " +
                          "FROM Clientes c " +
                          "LEFT JOIN Cotizaciones ct ON c.ChatId = ct.ClienteId " +
                          "GROUP BY c.ChatId, c.Nombre " +
                          "ORDER BY CantidadCotizaciones DESC;"; ;
            List<Usuario> listaAyudas = new List<Usuario>();
            try
            {
                using (SqlConnection _connection = _baseRepository.GetConnection())
                {
                    SqlDataAdapter adatador = new SqlDataAdapter(ssql, _connection);
                    DataSet ds = new DataSet();
                    adatador.Fill(ds);
                    var tabla = ds.Tables[0];
                    foreach (DataRow dr in tabla.Rows)
                    {
                        listaAyudas.Add(Mapper2(dr));
                    }
                }
                  
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listaAyudas;
        }

        public Usuario Mapper2(DataRow dr)
        {
            return new Usuario
            {
                IdUsuario = dr.Field<long>("idUsuario"), // Asegúrate de que "Id" es el nombre correcto de la columna
                NombreUsuario = dr.Field<string>("Nombre"),
                cantidadCotizaciones = dr.Field<int>("CantidadCotizaciones"), // Asegúrate de que "Codigo" es el nombre correcto de la columna
                
            };
        }
        
        private Usuario Mapper(SqlDataReader reader)
        {
            return new Usuario
            {
                IdUsuario = reader.GetInt64(reader.GetOrdinal("Idusuario")),
                NombreUsuario = reader.GetString(reader.GetOrdinal("Nombre")),
                cantidadCotizaciones = reader.GetInt32(reader.GetOrdinal("CantidadCotizaciones"))
               
            };
        }
    }
}
