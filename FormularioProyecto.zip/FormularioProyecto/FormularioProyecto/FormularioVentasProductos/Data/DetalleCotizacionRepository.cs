﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;
using System.Data.Odbc;
using Oracle.ManagedDataAccess.Client;

namespace Data
{
    public class DetalleCotizacionRepository
    {
        BaseRepository _baseRepository;

        public DetalleCotizacionRepository()
        {
            _baseRepository = new BaseRepository();
        }


        public List<DetalleCotizacion> SeleccionarRegistros1(int idCotizacion)
        {
               var Detalle = new List<DetalleCotizacion>();
            using (var connection = _baseRepository.GetConnection())
            {
                connection.Open();
                var query = "SELECT Id, Referencia, Nombre, Precio, CantidadEnStock FROM Productos WHERE idCotizacion = :id";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.Add(new OracleParameter("id", idCotizacion));

                    using (var reader = command.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            Detalle.Add(new DetalleCotizacion(
                            idCotizacion: reader.GetInt32(0),
                            idProducto: reader.GetInt32(1),
                            nombreProducto: reader.GetString(2),
                            cantidad: reader.GetInt32(3),
                            precio: reader.GetDecimal(4),
                            precioPorProducto: reader.GetDecimal(5)
                            ));
                        }
                    }
                }
            }
            return Detalle;
        }

        public List<DetalleCotizacion> SeleccionarRegistros(int idCotizacion)
        {
            string query = "SELECT dc.CotizacionId, dc.ProductoId, p.Nombre, dc.Cantidad, dc.PrecioUnitario, (dc.Cantidad * dc.PrecioUnitario) AS Total FROM DetalleCotizacion dc " +
                            "JOIN Productos p ON dc.ProductoId = p.Id "+
                            "WHERE dc.CotizacionId = @Id;";

            List<DetalleCotizacion> Detalle = new List<DetalleCotizacion>();
            try
            {
                using (var connection = _baseRepository.GetConnection())
                {
                    connection.Open();
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = idCotizacion });
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Detalle.Add(new DetalleCotizacion(
                                    idCotizacion: reader.GetInt32(0),
                                    idProducto: reader.GetInt32(1),
                                    nombreProducto: reader.GetString(2),
                                    cantidad: reader.GetInt32(3),
                                    precio: reader.GetDecimal(4),
                                    precioPorProducto: reader.GetDecimal(5)
                                ));
                            }
                        }
                    }
                }
                return Detalle;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }


        public bool AbrirConexion()
        {
            try
            {
                _baseRepository.GetConnection().Open();
                if (_baseRepository.GetConnection().State == ConnectionState.Open)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public bool CerrarConexion()
        {
            try
            {
                _baseRepository.GetConnection().Close();
                if (_baseRepository.GetConnection().State == ConnectionState.Closed)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
    }
}
