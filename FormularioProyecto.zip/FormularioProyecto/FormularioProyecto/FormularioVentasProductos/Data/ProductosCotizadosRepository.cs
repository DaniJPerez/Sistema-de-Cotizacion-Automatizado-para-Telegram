﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;
using System.IO;
using Oracle.ManagedDataAccess.Client;
namespace Data
{
    public class ProductosCotizadosRepository
    {
        //recuerda acregar el nombre de la base de datos para poder realizar las busquedas
        //                                 aqui=>   [->       <-]  
        private readonly BaseRepository _baseRepository;

        SqlConnection _connection;
        public ProductosCotizadosRepository()
        {
            _baseRepository = new BaseRepository();
        }

        public bool AbrirConexion()
        {
            try
            {
                _baseRepository.GetConnection().Open();
                if (_baseRepository.GetConnection().State == ConnectionState.Open)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public bool CerrarConexion()
        {
            try
            {
                _baseRepository.GetConnection().Close();
                if (_baseRepository.GetConnection().State == ConnectionState.Closed)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public List<ProductoCotizado> productosMasCotizados()
        {
            string ssql = "SELECT p.Id AS IdProducto, p.Referencia, p.Nombre, p.Precio, SUM(dc.Cantidad) AS CantidadCotizada " +
                          "FROM Productos p " +
                          "LEFT JOIN DetalleCotizacion dc ON p.Id = dc.ProductoId " +
                          "GROUP BY p.Id, p.Referencia, p.Nombre, p.Precio " +
                          "ORDER BY CantidadCotizada DESC;";
            List<ProductoCotizado> listaProductos = new List<ProductoCotizado>();
            try
            {
                using (var _connection= _baseRepository.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(ssql, _connection))
                    {
                        _connection.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaProductos.Add(Mapper(reader));
                            }
                        }
                     
                    }
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listaProductos;
        }

        public List<ProductoCotizado> productosMenosCotizados()
        {
            string ssql = "SELECT p.Id AS IdProducto, p.Referencia, p.Nombre, p.Precio, SUM(dc.Cantidad) AS CantidadCotizada " +
                          "FROM Productos p " +
                          "LEFT JOIN DetalleCotizacion dc ON p.Id = dc.ProductoId " +
                          "GROUP BY p.Id, p.Referencia, p.Nombre, p.Precio " +
                          "ORDER BY CantidadCotizada ASC;";
            List<ProductoCotizado> listaProductos = new List<ProductoCotizado>();
            try
            {
                using (var _connection = _baseRepository.GetConnection())
                {
                    using (var cmd = new SqlCommand(ssql, _connection))
                    {
                        _connection.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaProductos.Add(Mapper(reader));
                            }
                        }
                        
                    }
                }
                
            }
            catch (Exception ex)
            {
                return null;
            }
            return listaProductos;
        }

        public ProductoCotizado Mapper2(DataRow dr)
        {
            return new ProductoCotizado
            {
                IdProducto = dr.Field<int>("IdProducto"), // Asegúrate de que "Id" es el nombre correcto de la columna
                Referencia = dr.Field<string>("Referencia"),
                NombreProducto = dr.Field<string>("Nombre"), // Asegúrate de que "Codigo" es el nombre correcto de la columna
                Precio = dr.Field<decimal>("Precio"),
                VecesCotizado = dr.Field<int>("CantidadCotizada")// Asegúrate de que "Descripcion" es el nombre correcto de la columna

                
            };
        }

        private ProductoCotizado Mapper(SqlDataReader reader)
        {
            return new ProductoCotizado
            {
                IdProducto = reader.GetInt32(reader.GetOrdinal("IdProducto")),
                Referencia = reader.GetString(reader.GetOrdinal("Referencia")),
                NombreProducto = reader.GetString(reader.GetOrdinal("Nombre")),
                Precio = reader.GetDecimal(reader.GetOrdinal("Precio")),
                VecesCotizado = reader.IsDBNull(reader.GetOrdinal("CantidadCotizada")) ? 0 : reader.GetInt32(reader.GetOrdinal("CantidadCotizada"))

            };
        }

    }
}
