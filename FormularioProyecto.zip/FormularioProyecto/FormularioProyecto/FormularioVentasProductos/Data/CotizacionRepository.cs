﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidad;
using Oracle.ManagedDataAccess;
using Oracle.ManagedDataAccess.Client;

namespace Data
{
    public class CotizacionRepository
    {
        //recuerda acregar el nombre de la base de datos para porder realizar las busquedas
        //                                 aqui=>   [->       <-]  
        BaseRepository _baseRepository;
        
        public CotizacionRepository()
        {
           _baseRepository = new BaseRepository();
        }
        //1 conectarme

        public bool AbrirConexion()
        {
            try
            {
                _baseRepository.GetConnection().Open();
                if (_baseRepository.GetConnection().State == ConnectionState.Open)
                {
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }

        }
        public bool CerrarConexion()
        {
            try
            {
                _baseRepository.GetConnection().Close();
                if (_baseRepository.GetConnection().State == ConnectionState.Closed)
                {
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }

        }

        /* public List<Cotizacion> SeleccionarRegistros2()
         {
             string ssql = "SELECT * FROM Productos";
             List<Cotizacion> listaAyudas = new List<Cotizacion>();

             try
             {
                 // Usamos `using` para asegurar que la conexión se cierra automáticamente.
                 using (_connection)
                 {
                     using (SqlCommand cmd = new SqlCommand(ssql, _connection))
                     {
                         if (AbrirConexion())
                         {
                             using (var reader = cmd.ExecuteReader())
                             {
                                 while (reader.Read())
                                 {
                                     listaAyudas.Add(Mapper(reader));
                                 }
                             }
                         }
                     }
                 }
             }
             catch (Exception ex)
             {
                 // Loguear el error para facilitar la depuración
                 return null;
             }
             finally
             {
                 if (_connection.State == ConnectionState.Open)
                 {
                     _connection.Close(); // Aseguramos que la conexión se cierre
                 }
             }

             return listaAyudas;
         }*/


        public List<Cotizacion> SeleccionarRegistros()
        {   //Implementar correctamente la consulta segun la base de datos
            string ssql = "SELECT CotizacionId, ClienteId, Total, Fecha FROM Cotizaciones";
                           
            List<Cotizacion> listaCotizaciones = new List<Cotizacion>();

            try
            {
                using (var _connection= _baseRepository.GetConnection())
                {
                    _connection.Open();
                    using (SqlCommand cmd = new SqlCommand(ssql, _connection))
                    {
                        
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listaCotizaciones.Add(new Cotizacion(
                                    idCotizacion: reader.GetInt32(0),
                                    idUsuario: reader.GetInt64(1),
                                    total: reader.GetDecimal(2),
                                    fecha: reader.GetDateTime(3)
                                ));
                            }
                        }
                    }
                }
                
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
            return listaCotizaciones;
        }

       
      //  public Cotizacion Mapper2(DataRow dr)
        //{
        //    return new DetalleCotizacion8(dr);
            //{
                //IdProducto = dr.Field<int>("idCotizacion"), // Asegúrate de que "Id" es el nombre correcto de la columna
               // Referencia = dr.Field<string>("Referencia"), 
               // NombreProducto = dr.Field<string>("Nombre_Producto"), // Asegúrate de que "Codigo" es el nombre correcto de la columna
               // cantidadVendida = dr.Field<int>("Total_Vendido")// Asegúrate de que "Descripcion" es el nombre correcto de la columna
            //};
        //}

       // private Cotizacion Mapper(SqlDataReader reader)
        //{
            //return new DetalleCotizacion
          //  {
                //IdProducto = reader.GetString(reader.GetOrdinal("Id_producto")),
               // Referencia = reader.GetString(reader.GetOrdinal("Referencia")),
               // NombreProducto = reader.GetString(reader.GetOrdinal("Nombre_Producto")),
               // cantidadVendida = reader.GetInt32(reader.GetOrdinal("Total_Vendido"))
                
            //};
        //}
    }
}
