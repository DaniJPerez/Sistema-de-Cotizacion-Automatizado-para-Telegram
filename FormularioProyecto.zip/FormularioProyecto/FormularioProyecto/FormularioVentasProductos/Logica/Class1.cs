﻿namespace Logica
{
    public class Class1
    {

    }
}
