﻿namespace Formulario
{
    partial class ReporteCotizaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrillaCotizaciones = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GrillaCotizaciones)).BeginInit();
            this.SuspendLayout();
            // 
            // GrillaCotizaciones
            // 
            this.GrillaCotizaciones.AllowUserToAddRows = false;
            this.GrillaCotizaciones.AllowUserToDeleteRows = false;
            this.GrillaCotizaciones.BackgroundColor = System.Drawing.SystemColors.Control;
            this.GrillaCotizaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GrillaCotizaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrillaCotizaciones.Location = new System.Drawing.Point(65, 71);
            this.GrillaCotizaciones.Name = "GrillaCotizaciones";
            this.GrillaCotizaciones.ReadOnly = true;
            this.GrillaCotizaciones.Size = new System.Drawing.Size(632, 344);
            this.GrillaCotizaciones.TabIndex = 1;
            this.GrillaCotizaciones.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrillaPedidos_CellContentClick);
            // 
            // ReporteCotizaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.ClientSize = new System.Drawing.Size(776, 451);
            this.Controls.Add(this.GrillaCotizaciones);
            this.Name = "ReporteCotizaciones";
            this.Text = "ReportePedidos";
            this.Load += new System.EventHandler(this.ReporteCotizaciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrillaCotizaciones)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView GrillaCotizaciones;
    }
}