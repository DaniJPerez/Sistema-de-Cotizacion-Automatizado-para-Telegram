﻿namespace Formulario
{
    partial class GestionProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txtNombreProductoAgregar = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.txtPrecioAgregar = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtStockAgregar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtReferenciaAgregar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtIdProductoAgregar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombreProductoActualizar = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.txtPrecioEditar = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtStockEditar = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtReferenciaEditar = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtIdProductoEditar = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.GrillaProductos = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txtNombreProductoEliminar = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdProductoEliminar = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnMostrarProductos = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrillaProductos)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(12, 24);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txtNombreProductoAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.label17);
            this.splitContainer1.Panel1.Controls.Add(this.btnAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.txtPrecioAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.txtStockAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.txtReferenciaAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.txtIdProductoAgregar);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.txtNombreProductoActualizar);
            this.splitContainer1.Panel2.Controls.Add(this.label16);
            this.splitContainer1.Panel2.Controls.Add(this.btnActualizar);
            this.splitContainer1.Panel2.Controls.Add(this.txtPrecioEditar);
            this.splitContainer1.Panel2.Controls.Add(this.label8);
            this.splitContainer1.Panel2.Controls.Add(this.txtStockEditar);
            this.splitContainer1.Panel2.Controls.Add(this.label9);
            this.splitContainer1.Panel2.Controls.Add(this.txtReferenciaEditar);
            this.splitContainer1.Panel2.Controls.Add(this.label10);
            this.splitContainer1.Panel2.Controls.Add(this.txtIdProductoEditar);
            this.splitContainer1.Panel2.Controls.Add(this.label11);
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Size = new System.Drawing.Size(327, 410);
            this.splitContainer1.SplitterDistance = 198;
            this.splitContainer1.TabIndex = 1;
            // 
            // txtNombreProductoAgregar
            // 
            this.txtNombreProductoAgregar.Location = new System.Drawing.Point(112, 89);
            this.txtNombreProductoAgregar.Name = "txtNombreProductoAgregar";
            this.txtNombreProductoAgregar.Size = new System.Drawing.Size(197, 20);
            this.txtNombreProductoAgregar.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 10;
            this.label17.Text = "Nombre";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(232, 172);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 9;
            this.btnAgregar.Text = "AGREGAR";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // txtPrecioAgregar
            // 
            this.txtPrecioAgregar.Location = new System.Drawing.Point(110, 146);
            this.txtPrecioAgregar.Name = "txtPrecioAgregar";
            this.txtPrecioAgregar.Size = new System.Drawing.Size(197, 20);
            this.txtPrecioAgregar.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Precio";
            // 
            // txtStockAgregar
            // 
            this.txtStockAgregar.Location = new System.Drawing.Point(110, 120);
            this.txtStockAgregar.Name = "txtStockAgregar";
            this.txtStockAgregar.Size = new System.Drawing.Size(197, 20);
            this.txtStockAgregar.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Stock";
            // 
            // txtReferenciaAgregar
            // 
            this.txtReferenciaAgregar.Location = new System.Drawing.Point(112, 55);
            this.txtReferenciaAgregar.Name = "txtReferenciaAgregar";
            this.txtReferenciaAgregar.Size = new System.Drawing.Size(197, 20);
            this.txtReferenciaAgregar.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Referencia";
            // 
            // txtIdProductoAgregar
            // 
            this.txtIdProductoAgregar.Location = new System.Drawing.Point(110, 29);
            this.txtIdProductoAgregar.Name = "txtIdProductoAgregar";
            this.txtIdProductoAgregar.Size = new System.Drawing.Size(197, 20);
            this.txtIdProductoAgregar.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Id Producto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "AGREGAR PRODUCTO";
            // 
            // txtNombreProductoActualizar
            // 
            this.txtNombreProductoActualizar.Location = new System.Drawing.Point(112, 94);
            this.txtNombreProductoActualizar.Name = "txtNombreProductoActualizar";
            this.txtNombreProductoActualizar.Size = new System.Drawing.Size(197, 20);
            this.txtNombreProductoActualizar.TabIndex = 19;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 101);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "Nombre";
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(232, 182);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(75, 23);
            this.btnActualizar.TabIndex = 17;
            this.btnActualizar.Text = "ACTUALIZAR";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // txtPrecioEditar
            // 
            this.txtPrecioEditar.Location = new System.Drawing.Point(110, 156);
            this.txtPrecioEditar.Name = "txtPrecioEditar";
            this.txtPrecioEditar.Size = new System.Drawing.Size(197, 20);
            this.txtPrecioEditar.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Precio";
            // 
            // txtStockEditar
            // 
            this.txtStockEditar.Location = new System.Drawing.Point(110, 130);
            this.txtStockEditar.Name = "txtStockEditar";
            this.txtStockEditar.Size = new System.Drawing.Size(197, 20);
            this.txtStockEditar.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 137);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Stock";
            // 
            // txtReferenciaEditar
            // 
            this.txtReferenciaEditar.Location = new System.Drawing.Point(110, 62);
            this.txtReferenciaEditar.Name = "txtReferenciaEditar";
            this.txtReferenciaEditar.Size = new System.Drawing.Size(197, 20);
            this.txtReferenciaEditar.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Referencia";
            // 
            // txtIdProductoEditar
            // 
            this.txtIdProductoEditar.Location = new System.Drawing.Point(110, 36);
            this.txtIdProductoEditar.Name = "txtIdProductoEditar";
            this.txtIdProductoEditar.Size = new System.Drawing.Size(197, 20);
            this.txtIdProductoEditar.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Id Producto";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "EDITAR PRODUCTO";
            // 
            // GrillaProductos
            // 
            this.GrillaProductos.BackgroundColor = System.Drawing.SystemColors.Control;
            this.GrillaProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrillaProductos.Location = new System.Drawing.Point(404, 61);
            this.GrillaProductos.Name = "GrillaProductos";
            this.GrillaProductos.Size = new System.Drawing.Size(773, 494);
            this.GrillaProductos.TabIndex = 6;
            this.GrillaProductos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrillaProductos_CellClick);
            this.GrillaProductos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrillaProductos_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnEliminar);
            this.panel1.Controls.Add(this.txtNombreProductoEliminar);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtIdProductoEliminar);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(12, 440);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(327, 162);
            this.panel1.TabIndex = 7;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(232, 121);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 21;
            this.btnEliminar.Text = "ELIMINAR";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // txtNombreProductoEliminar
            // 
            this.txtNombreProductoEliminar.Location = new System.Drawing.Point(110, 95);
            this.txtNombreProductoEliminar.Name = "txtNombreProductoEliminar";
            this.txtNombreProductoEliminar.Size = new System.Drawing.Size(197, 20);
            this.txtNombreProductoEliminar.TabIndex = 20;
            this.txtNombreProductoEliminar.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Nombre";
            // 
            // txtIdProductoEliminar
            // 
            this.txtIdProductoEliminar.Location = new System.Drawing.Point(110, 24);
            this.txtIdProductoEliminar.Name = "txtIdProductoEliminar";
            this.txtIdProductoEliminar.Size = new System.Drawing.Size(197, 20);
            this.txtIdProductoEliminar.TabIndex = 16;
            this.txtIdProductoEliminar.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 15;
            this.label15.Text = "Id Producto";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "ELIMIAR PRODUCTO";
            // 
            // btnMostrarProductos
            // 
            this.btnMostrarProductos.Location = new System.Drawing.Point(1074, 579);
            this.btnMostrarProductos.Name = "btnMostrarProductos";
            this.btnMostrarProductos.Size = new System.Drawing.Size(103, 23);
            this.btnMostrarProductos.TabIndex = 8;
            this.btnMostrarProductos.Text = "Mostrar Productos";
            this.btnMostrarProductos.UseVisualStyleBackColor = true;
            this.btnMostrarProductos.Click += new System.EventHandler(this.btnMostrarProductos_Click);
            // 
            // GestionProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.ClientSize = new System.Drawing.Size(1231, 616);
            this.Controls.Add(this.btnMostrarProductos);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.GrillaProductos);
            this.Controls.Add(this.splitContainer1);
            this.Name = "GestionProductos";
            this.Text = "GestionProductos";
            this.Load += new System.EventHandler(this.GestionProductos_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GrillaProductos)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdProductoAgregar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPrecioAgregar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtStockAgregar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtReferenciaAgregar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPrecioEditar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtStockEditar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtReferenciaEditar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtIdProductoEditar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.DataGridView GrillaProductos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNombreProductoEliminar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdProductoEliminar;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.TextBox txtNombreProductoAgregar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtNombreProductoActualizar;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnMostrarProductos;
    }
}