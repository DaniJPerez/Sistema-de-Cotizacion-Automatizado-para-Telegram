﻿namespace Formulario
{
    partial class ReporteProductosCotizados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProdMas = new System.Windows.Forms.Button();
            this.btnProdMenos = new System.Windows.Forms.Button();
            this.GrillaProductosCotizados = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GrillaProductosCotizados)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProdMas
            // 
            this.btnProdMas.BackColor = System.Drawing.Color.White;
            this.btnProdMas.Location = new System.Drawing.Point(23, 82);
            this.btnProdMas.Name = "btnProdMas";
            this.btnProdMas.Size = new System.Drawing.Size(124, 23);
            this.btnProdMas.TabIndex = 2;
            this.btnProdMas.Text = "Mas Cotizados";
            this.btnProdMas.UseVisualStyleBackColor = false;
            this.btnProdMas.Click += new System.EventHandler(this.btnProdMas_Click);
            // 
            // btnProdMenos
            // 
            this.btnProdMenos.BackColor = System.Drawing.Color.White;
            this.btnProdMenos.Location = new System.Drawing.Point(23, 133);
            this.btnProdMenos.Name = "btnProdMenos";
            this.btnProdMenos.Size = new System.Drawing.Size(124, 23);
            this.btnProdMenos.TabIndex = 3;
            this.btnProdMenos.Text = "Menos Cotizados";
            this.btnProdMenos.UseVisualStyleBackColor = false;
            this.btnProdMenos.Click += new System.EventHandler(this.btnProdMenos_Click_1);
            // 
            // GrillaProductosCotizados
            // 
            this.GrillaProductosCotizados.BackgroundColor = System.Drawing.SystemColors.Control;
            this.GrillaProductosCotizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrillaProductosCotizados.Location = new System.Drawing.Point(187, 67);
            this.GrillaProductosCotizados.Name = "GrillaProductosCotizados";
            this.GrillaProductosCotizados.Size = new System.Drawing.Size(605, 332);
            this.GrillaProductosCotizados.TabIndex = 10;
            // 
            // ReporteProductosCotizados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.ClientSize = new System.Drawing.Size(920, 451);
            this.Controls.Add(this.GrillaProductosCotizados);
            this.Controls.Add(this.btnProdMenos);
            this.Controls.Add(this.btnProdMas);
            this.Name = "ReporteProductosCotizados";
            this.Text = "ReporteProductosVendidos";
            this.Load += new System.EventHandler(this.ReporteProductosVendidos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrillaProductosCotizados)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnProdMas;
        private System.Windows.Forms.Button btnProdMenos;
        private System.Windows.Forms.DataGridView GrillaProductosCotizados;
    }
}