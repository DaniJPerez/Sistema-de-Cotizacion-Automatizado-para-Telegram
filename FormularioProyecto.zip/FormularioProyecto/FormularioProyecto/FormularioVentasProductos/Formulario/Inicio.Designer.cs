﻿namespace Formulario
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSalir = new System.Windows.Forms.Button();
            this.buttonReporteUsuarios = new System.Windows.Forms.Button();
            this.buttonProductoVendidos = new System.Windows.Forms.Button();
            this.buttonReporteCotizaciones = new System.Windows.Forms.Button();
            this.PnInicioOpciones = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PnInicio = new System.Windows.Forms.Panel();
            this.PnInicioOpciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSalir
            // 
            this.buttonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonSalir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSalir.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonSalir.Location = new System.Drawing.Point(20, 519);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(309, 58);
            this.buttonSalir.TabIndex = 10;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = false;
            this.buttonSalir.Click += new System.EventHandler(this.buttonSalir_Click);
            // 
            // buttonReporteUsuarios
            // 
            this.buttonReporteUsuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonReporteUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReporteUsuarios.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReporteUsuarios.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonReporteUsuarios.Location = new System.Drawing.Point(20, 345);
            this.buttonReporteUsuarios.Name = "buttonReporteUsuarios";
            this.buttonReporteUsuarios.Size = new System.Drawing.Size(309, 58);
            this.buttonReporteUsuarios.TabIndex = 9;
            this.buttonReporteUsuarios.Text = "Reporte de Usuarios";
            this.buttonReporteUsuarios.UseVisualStyleBackColor = false;
            this.buttonReporteUsuarios.Click += new System.EventHandler(this.buttonReporteUsuarios_Click);
            // 
            // buttonProductoVendidos
            // 
            this.buttonProductoVendidos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonProductoVendidos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonProductoVendidos.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProductoVendidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonProductoVendidos.Location = new System.Drawing.Point(20, 431);
            this.buttonProductoVendidos.Name = "buttonProductoVendidos";
            this.buttonProductoVendidos.Size = new System.Drawing.Size(307, 58);
            this.buttonProductoVendidos.TabIndex = 8;
            this.buttonProductoVendidos.Text = "Reporte de Productos mas Cotizados";
            this.buttonProductoVendidos.UseVisualStyleBackColor = false;
            this.buttonProductoVendidos.Click += new System.EventHandler(this.buttonProductoVendidos_Click);
            // 
            // buttonReporteCotizaciones
            // 
            this.buttonReporteCotizaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.buttonReporteCotizaciones.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReporteCotizaciones.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReporteCotizaciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(13)))), ((int)(((byte)(13)))));
            this.buttonReporteCotizaciones.Location = new System.Drawing.Point(20, 253);
            this.buttonReporteCotizaciones.Name = "buttonReporteCotizaciones";
            this.buttonReporteCotizaciones.Size = new System.Drawing.Size(307, 58);
            this.buttonReporteCotizaciones.TabIndex = 6;
            this.buttonReporteCotizaciones.Text = "Reporte de Cotizaciones";
            this.buttonReporteCotizaciones.UseVisualStyleBackColor = false;
            this.buttonReporteCotizaciones.Click += new System.EventHandler(this.buttonReporteVentas_Click);
            // 
            // PnInicioOpciones
            // 
            this.PnInicioOpciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.PnInicioOpciones.Controls.Add(this.pictureBox1);
            this.PnInicioOpciones.Controls.Add(this.buttonReporteCotizaciones);
            this.PnInicioOpciones.Controls.Add(this.buttonSalir);
            this.PnInicioOpciones.Controls.Add(this.buttonReporteUsuarios);
            this.PnInicioOpciones.Controls.Add(this.buttonProductoVendidos);
            this.PnInicioOpciones.Location = new System.Drawing.Point(1, 0);
            this.PnInicioOpciones.Name = "PnInicioOpciones";
            this.PnInicioOpciones.Size = new System.Drawing.Size(364, 681);
            this.PnInicioOpciones.TabIndex = 13;
            this.PnInicioOpciones.Resize += new System.EventHandler(this.PnInicioOpciones_Resize);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Formulario.Properties.Resources._20240922_155638_removebg;
            this.pictureBox1.Location = new System.Drawing.Point(20, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 206);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // PnInicio
            // 
            this.PnInicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.PnInicio.Location = new System.Drawing.Point(362, 0);
            this.PnInicio.Name = "PnInicio";
            this.PnInicio.Size = new System.Drawing.Size(1162, 681);
            this.PnInicio.TabIndex = 14;
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1523, 681);
            this.Controls.Add(this.PnInicio);
            this.Controls.Add(this.PnInicioOpciones);
            this.Name = "Inicio";
            this.Text = "Inicio";
            this.Load += new System.EventHandler(this.Inicio_Load);
            this.PnInicioOpciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSalir;
        private System.Windows.Forms.Button buttonReporteUsuarios;
        private System.Windows.Forms.Button buttonProductoVendidos;
        private System.Windows.Forms.Button buttonReporteCotizaciones;
        private System.Windows.Forms.Panel PnInicioOpciones;
        private System.Windows.Forms.Panel PnInicio;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}