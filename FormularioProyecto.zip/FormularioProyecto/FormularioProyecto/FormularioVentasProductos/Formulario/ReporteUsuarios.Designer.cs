﻿namespace Formulario
{
    partial class ReporteUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrillaUsuarios = new System.Windows.Forms.DataGridView();
            this.btnMayor = new System.Windows.Forms.Button();
            this.btnMenores = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GrillaUsuarios)).BeginInit();
            this.SuspendLayout();
            // 
            // GrillaUsuarios
            // 
            this.GrillaUsuarios.AllowUserToAddRows = false;
            this.GrillaUsuarios.AllowUserToDeleteRows = false;
            this.GrillaUsuarios.BackgroundColor = System.Drawing.SystemColors.Control;
            this.GrillaUsuarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GrillaUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrillaUsuarios.Location = new System.Drawing.Point(187, 61);
            this.GrillaUsuarios.Name = "GrillaUsuarios";
            this.GrillaUsuarios.ReadOnly = true;
            this.GrillaUsuarios.Size = new System.Drawing.Size(605, 333);
            this.GrillaUsuarios.TabIndex = 1;
            // 
            // btnMayor
            // 
            this.btnMayor.Location = new System.Drawing.Point(48, 70);
            this.btnMayor.Name = "btnMayor";
            this.btnMayor.Size = new System.Drawing.Size(111, 23);
            this.btnMayor.TabIndex = 12;
            this.btnMayor.Text = "Mayor Cotizaciones";
            this.btnMayor.UseVisualStyleBackColor = true;
            this.btnMayor.Click += new System.EventHandler(this.btnMayor_Click);
            // 
            // btnMenores
            // 
            this.btnMenores.Location = new System.Drawing.Point(48, 121);
            this.btnMenores.Name = "btnMenores";
            this.btnMenores.Size = new System.Drawing.Size(111, 23);
            this.btnMenores.TabIndex = 13;
            this.btnMenores.Text = "Menor Cotizaciones";
            this.btnMenores.UseVisualStyleBackColor = true;
            this.btnMenores.Click += new System.EventHandler(this.btnMenores_Click);
            // 
            // ReporteUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(214)))), ((int)(((byte)(179)))));
            this.ClientSize = new System.Drawing.Size(931, 451);
            this.Controls.Add(this.btnMenores);
            this.Controls.Add(this.btnMayor);
            this.Controls.Add(this.GrillaUsuarios);
            this.Name = "ReporteUsuarios";
            this.Text = "ReporteDeUsuarios";
            this.Load += new System.EventHandler(this.ReporteUsuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrillaUsuarios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView GrillaUsuarios;
        private System.Windows.Forms.Button btnMayor;
        private System.Windows.Forms.Button btnMenores;
    }
}