﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class ProductoCotizado
    {
        public int IdProducto { get; set; }
        public string Referencia { get; set; }
        public string NombreProducto { get; set; }
        public decimal Precio {  get; set; }
        public int VecesCotizado{ get; set; } 

        public ProductoCotizado() { }
        public ProductoCotizado(int idProducto, string referencia, string nombreProducto, decimal precio,int vecesCotizado)
        {
            IdProducto = idProducto;
            Referencia = referencia;
            NombreProducto = nombreProducto;
            precio = precio;
            this.VecesCotizado = vecesCotizado;
        }
    }
}
