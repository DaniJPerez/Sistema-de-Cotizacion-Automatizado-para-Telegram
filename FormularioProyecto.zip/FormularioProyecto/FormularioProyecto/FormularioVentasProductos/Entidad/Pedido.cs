﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Pedido
    {
        public string idProducto {  get; set; }
        public string Feferencia { get; set; }
        public string nombreProducto { get; set; }
        public int cantidad { get; set; }
        public string idUsuario { get; set; }
        public string nombreUsuario { get; set; }

        public Pedido ()
        {

        }

        public Pedido (string idProducto, string referencia, string nombreProducto, int cantidad, string idUsuario, string nombreUsuario)
        {
            this.idProducto = idProducto;
            this.Feferencia = referencia;
            this.nombreProducto = nombreProducto;
            this.cantidad = cantidad;
            this.idUsuario = idUsuario;
            this.nombreUsuario = nombreUsuario;
        }

        public Pedido (string idProducto, string referencia, string nombreProducto, int cantidad, string nombreUsuario)
        {
            this.idProducto = idProducto;
            this.Feferencia = referencia;
            this.nombreProducto = nombreProducto;
            this.cantidad = cantidad;
            this.nombreUsuario = nombreUsuario;
        }
    }
}
