﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Cotizacion
    {
        
        public int idCotizacion {  get; set; }

        //public int idNegocio;

        public decimal total {  get; set; }

        public long idUsuario { get; set; }

        public DateTime fecha { get; set; }

        public Cotizacion()
        {

        }

        public Cotizacion(int idCotizacion, decimal total, long idUsuario, DateTime fecha)
        {
            this.idCotizacion = idCotizacion;
            this.total = total;
            this.idUsuario = idUsuario;
            this.fecha = fecha;
        }
    }
}

