﻿namespace Datos
{
    public class BaseRepository
    {

    }
}
